#!/usr/bin/env bash
# One-command start of the production Compose bundle (W4-DEP-02).
#
#   ./start.sh            create .env if needed, run `mpbx init` once (shows the recovery key), start everything
#   ./start.sh down       stop (keeps the volumes)
#
# Any other arguments are passed to `docker compose` (for example `./start.sh logs -f mpbx`).
# Set COMPOSE_PROJECT_NAME to run a second copy side by side (default: mpbx-prod).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# compose.init.yaml and compose.yaml are one project; the init container is not an orphan.
export COMPOSE_IGNORE_ORPHANS=true

case "$(uname -s)" in
  Linux) files=(-f compose.yaml -f compose.linux.yaml) ;;
  *)     files=(-f compose.yaml -f compose.desktop.yaml)
         echo "start.sh: not Linux: using compose.desktop.yaml (bridge networking, reduced RTP range, dev/trial only)" >&2 ;;
esac

if [ ! -f .env ]; then
  umask 077
  cp .env.example .env
  echo "start.sh: created .env from .env.example; set MPBX_IMAGE and MPBX_RTPENGINE_IMAGE in it and run again" >&2
  exit 1
fi
chmod 600 .env
value() { sed -n "s/^$1=\(.*\)$/\1/p" .env | tail -n1; }
for v in MPBX_IMAGE MPBX_RTPENGINE_IMAGE; do
  [ -n "$(value "$v")" ] || { echo "start.sh: set $v in .env" >&2; exit 1; }
done

# The init container runs as you, so .env stays yours and mode 0600.
MPBX_UID="$(id -u)"; MPBX_GID="$(id -g)"; export MPBX_UID MPBX_GID

if [ -z "$(value MPBX_MASTER_KEY)" ]; then
  tty_flag=()
  [ -t 0 ] || tty_flag=(-T)
  docker compose -f compose.init.yaml run --rm "${tty_flag[@]}" init
fi

# Linux host networking: rtpengine needs the local address it binds RTP to.
if [ "$(uname -s)" = Linux ] && [ -z "$(value RTPE_INTERFACE)" ]; then
  addr="$(ip -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p' | head -n1 || true)"
  [ -n "$addr" ] || { echo "start.sh: cannot detect the local address; set RTPE_INTERFACE in .env" >&2; exit 1; }
  printf 'RTPE_INTERFACE=%s\n' "$addr" >> .env
  echo "start.sh: RTPE_INTERFACE=$addr (written to .env)" >&2
fi

# Linux: the services on the host network export their metrics on the Docker bridge gateway so Prometheus (a bridge
# container) can scrape them (compose.linux.yaml, prometheus.linux.yml). Default 172.17.0.1.
if [ "$(uname -s)" = Linux ] && [ -z "$(value MPBX_METRICS_BIND)" ]; then
  gw="$(docker network inspect bridge --format '{{(index .IPAM.Config 0).Gateway}}' 2>/dev/null || true)"
  case "$gw" in
    [0-9]*.[0-9]*.[0-9]*.[0-9]*)
      printf 'MPBX_METRICS_BIND=%s\n' "$gw" >> .env
      echo "start.sh: MPBX_METRICS_BIND=$gw (written to .env)" >&2 ;;
  esac
fi

if [ "$#" -eq 0 ]; then
  exec docker compose "${files[@]}" up -d --wait
fi
if [ "$1" = down ]; then
  shift
  exec docker compose "${files[@]}" down "$@"
fi
exec docker compose "${files[@]}" "$@"
