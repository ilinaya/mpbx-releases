#!/usr/bin/env bash
# Third-party image bump helper (FU-DEP02-L4). Prints, for every digest-pinned third-party image in compose.yaml, the
# digest its tag points to NOW (multi-arch index digest, as `docker buildx imagetools inspect` reports it).
#   bump-images.sh            show: "current" vs "new" per image, nothing is changed
#   bump-images.sh --apply    rewrite compose.yaml with the new digests (review the diff, run validate.sh and the scan)
# Needs docker with buildx and network access. Never run from CI (CI only scans, deploy/cloudbuild/images.yaml).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
apply=0; [ "${1:-}" = "--apply" ] && apply=1
changed=0
while IFS= read -r ref; do
  name="${ref%@*}"; old="${ref#*@}"
  new="$(docker buildx imagetools inspect "$name" --format '{{.Manifest.Digest}}')"
  case "$new" in sha256:[0-9a-f]*) ;; *) echo "error: no digest for $name" >&2; exit 1 ;; esac
  if [ "$new" = "$old" ]; then
    echo "up to date  $name"
  else
    echo "NEW DIGEST  $name"; echo "    current $old"; echo "    new     $new"; changed=1
    if [ "$apply" = 1 ]; then
      tmp="$(mktemp)"; sed "s|$name@$old|$name@$new|g" compose.yaml >"$tmp" && cat "$tmp" >compose.yaml; rm -f "$tmp"
    fi
  fi
done < <(grep -hoE 'image: *[^[:space:]{}]+@sha256:[0-9a-f]{64}' compose.yaml | sed 's/^image: *//' | sort -u)
if [ "$changed" = 1 ] && [ "$apply" = 0 ]; then echo "re-run with --apply to rewrite compose.yaml"; fi
echo "next: scripts/validate.sh, then the images.yaml scan (scan-third-party-images) on the PR build"
