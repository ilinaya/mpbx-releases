#!/usr/bin/env bash
# Fetches the pinned Grafana ClickHouse datasource plugin once, checks its SHA-256 and unpacks it for an air-gapped
# install (FU-OBS01-L4; compose.grafana-offline.yaml, docs/guides/observability.md "Air-gapped hosts").
#
#   deploy/compose/prod/scripts/vendor-grafana-plugin.sh <dest-dir> [--trust-first-use]
#
# The version is the one compose.yaml installs (GF_PLUGINS_PREINSTALL). The expected digest is in
# deploy/compose/prod/grafana-plugin.sha256 ("<sha256>  grafana-clickhouse-datasource-<version>.zip"). While that file is
# absent the script refuses, unless --trust-first-use is given: it then prints the digest, which you review and commit
# (the release engineer does this once per plugin bump). Licence: the plugin is Apache-2.0.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
dest="${1:?usage: vendor-grafana-plugin.sh <dest-dir> [--trust-first-use]}"
tofu="${2:-}"
ver="$(sed -n 's/.*GF_PLUGINS_PREINSTALL: *grafana-clickhouse-datasource@\([0-9][0-9.]*\).*/\1/p' "$here/compose.yaml" | head -n1)"
[ -n "$ver" ] || { echo "cannot read the plugin version from compose.yaml" >&2; exit 1; }
zip_name="grafana-clickhouse-datasource-$ver.zip"
work="$(mktemp -d)"; trap 'rm -rf "$work"' EXIT
curl -fsSL --proto '=https' --tlsv1.2 -o "$work/$zip_name" \
  "https://grafana.com/api/plugins/grafana-clickhouse-datasource/versions/$ver/download"
sum="$( (sha256sum "$work/$zip_name" 2>/dev/null || shasum -a 256 "$work/$zip_name") | awk '{print $1}')"
pin="$here/grafana-plugin.sha256"
if [ -f "$pin" ]; then
  want="$(awk -v f="$zip_name" '$2 == f {print $1}' "$pin")"
  [ -n "$want" ] || { echo "$pin has no line for $zip_name" >&2; exit 1; }
  [ "$want" = "$sum" ] || { echo "DIGEST MISMATCH for $zip_name: expected $want, got $sum" >&2; exit 1; }
elif [ "$tofu" = "--trust-first-use" ]; then
  echo "no $pin yet: review and commit this line:"
  echo "$sum  $zip_name"
else
  echo "$pin is missing; run with --trust-first-use once and commit the printed digest" >&2
  exit 1
fi
mkdir -p "$dest"
unzip -q -o "$work/$zip_name" -d "$dest"
echo "plugin $ver unpacked into $dest (sha256 $sum)"
