#!/bin/sh
# Starts rtpengine (stock upstream build, userspace forwarding: --table=-1) with the interface and ports from the
# environment. Mounted into the mpbx-rtpengine image by compose.yaml; the image itself holds only the binary
# and passes no addresses (they belong to the deployment, DECISIONS Round 7).
#
# RTPE_INTERFACE   local address RTP binds to. Required with host networking (start.sh detects it);
#                  the container's own address in bridge mode.
# RTPE_ADVERTISE   public address put into SDP (behind NAT / cloud 1:1 NAT). Optional.
# RTPE_ADVERTISE_MAP  FU-DEP03-L2: per-node public addresses, comma separated `<RTPE_INTERFACE>=<public address>`
#                  pairs (for example `10.0.0.5=203.0.113.5,10.0.0.6=203.0.113.6`). The entry whose key is this
#                  node's RTPE_INTERFACE wins over RTPE_ADVERTISE, so several media nodes behind 1:1 NAT share ONE
#                  configuration (Kubernetes: one ConfigMap for the whole DaemonSet). No entry: RTPE_ADVERTISE.
# RTPE_NG_LISTEN   NG bind address. NG is UNAUTHENTICATED: loopback on the host network, never published.
# RTPE_NG_PORT, RTPE_PORT_MIN, RTPE_PORT_MAX, RTPE_LOG_LEVEL
# RTPE_TIMEOUT        seconds without any RTP before rtpengine deletes a session on its own (default 300;
#                     rtpengine's own default is 60). A caller queued at an emergency centre with early media
#                     and no RTP must not lose its media relay: rtpengine has no per-call timeout, so this global
#                     value is raised, and the B2BUA re-anchors an emergency call whose session is gone anyway
#                     (docs/guides/emergency.md). Every session is deleted by the PBX when its call ends, and
#                     normal calls are bounded by ring_timeout and max_call_duration, so nothing leaks longer.
# RTPE_SILENT_TIMEOUT seconds a session on hold / one-way may stay without RTP from one side (default 3600).
# RTPE_INTERFACE6  W10-NET-01 (dual stack): local IPv6 address RTP also binds to. Optional; when set, the one
#                  logical interface holds both families, so IPv6 phones get IPv6 media, IPv4 trunks IPv4 media
#                  (the PBX names the family per leg) and WebRTC legs get ICE candidates of both families.
# RTPE_ADVERTISE6  public IPv6 address put into SDP for the IPv6 interface. Optional (IPv6 is rarely NATed).
# RTPE_RECORDING_DIR  FU-TRACE-4a: when set (compose.trace-rtp.yaml), rtpengine can record the media of a call into this
#                  directory in pcap mode (userspace forwarding only), raw IP packets. The call engine asks for it per
#                  call, only for calls a company's SIP trace session with RTP capture traces, and collects the files
#                  from the same directory (MPBX_SIPTRACE_RTP_DIR). Nothing is recorded without that request.
# RTPE_TOS         W10-MED-01: TOS byte of outgoing RTP (default 184 = DSCP 46, EF; 0 leaves RTP unmarked).
set -eu
LOCAL="${RTPE_INTERFACE:-}"
if [ -z "$LOCAL" ]; then
  # Bridge mode: the container's own address (its hostname resolves to it).
  LOCAL="$(hostname -i 2>/dev/null | awk '{print $1}')"
fi
[ -n "$LOCAL" ] || { echo "rtpengine: cannot determine the local address; set RTPE_INTERFACE" >&2; exit 1; }
ADV="${RTPE_ADVERTISE:-}"
if [ -n "${RTPE_ADVERTISE_MAP:-}" ]; then
  # Exact match on the key (no regex): the node address only.
  MAPPED="$(printf '%s' "$RTPE_ADVERTISE_MAP" | tr ',' '\n' | awk -F= -v k="$LOCAL" '{ gsub(/[ \t]/, "") } $1 == k { print $2; exit }')"
  [ -z "$MAPPED" ] || ADV="$MAPPED"
fi
IFACE="$LOCAL"
[ -z "$ADV" ] || IFACE="${LOCAL}!${ADV}"
# FU-W5QA04-3: rtpengine uses 4 UDP ports per relayed call, so the range carries (max - min + 1) / 4 calls.
PMIN="${RTPE_PORT_MIN:-30000}"; PMAX="${RTPE_PORT_MAX:-40000}"
case "$PMIN$PMAX" in *[!0-9]*) echo "rtpengine: RTPE_PORT_MIN / RTPE_PORT_MAX must be numbers" >&2; exit 1 ;; esac
[ "$PMIN" -lt "$PMAX" ] || { echo "rtpengine: RTPE_PORT_MIN must be lower than RTPE_PORT_MAX" >&2; exit 1; }
echo "rtpengine: RTP range ${PMIN}-${PMAX} carries about $(( (PMAX - PMIN + 1) / 4 )) concurrent relayed calls (4 ports per call)"
set -- --interface="$IFACE"
IFACE6=""
if [ -n "${RTPE_INTERFACE6:-}" ]; then
  IFACE6="$RTPE_INTERFACE6"
  [ -z "${RTPE_ADVERTISE6:-}" ] || IFACE6="${RTPE_INTERFACE6}!${RTPE_ADVERTISE6}"
  set -- "$@" --interface="$IFACE6"
fi
if [ -n "${RTPE_RECORDING_DIR:-}" ]; then
  set -- "$@" --recording-dir="$RTPE_RECORDING_DIR" --recording-method=pcap --recording-format=raw
fi
TOS="${RTPE_TOS:-184}"
[ "$TOS" = "0" ] || set -- "$@" --tos="$TOS"
echo "rtpengine: interface=${IFACE}${IFACE6:+ interface6=${IFACE6}} tos=${TOS} ng=${RTPE_NG_LISTEN:-127.0.0.1}:${RTPE_NG_PORT:-22222} rtp=${RTPE_PORT_MIN:-30000}-${RTPE_PORT_MAX:-40000}"
exec /usr/local/bin/rtpengine --foreground --log-stderr --table=-1 \
  "$@" \
  --listen-ng="${RTPE_NG_LISTEN:-127.0.0.1}:${RTPE_NG_PORT:-22222}" \
  --port-min="${RTPE_PORT_MIN:-30000}" --port-max="${RTPE_PORT_MAX:-40000}" \
  --timeout="${RTPE_TIMEOUT:-300}" --silent-timeout="${RTPE_SILENT_TIMEOUT:-3600}" \
  --log-level="${RTPE_LOG_LEVEL:-5}"
