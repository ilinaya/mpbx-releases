#!/usr/bin/env python3
"""Per-company read-only ClickHouse users for Grafana (FU-OBS01-L3).

`mpbx_ro` (users.d/readonly.xml) reads every company. A company whose staff get Grafana logins needs its own
ClickHouse user that can only see its own rows. This tool writes `clickhouse/company-users.xml`, mounted next to
readonly.xml: one user `mpbx_ro_<slug>` per company, with

  * `GRANT SELECT` on the tenant tables only (fail closed: a table that is not listed is denied, so a new table is
    invisible to company users until this file is regenerated and reviewed),
  * a row filter `tenant_id = toUUID('<company id>')` on each of those tables (the `<databases>` row policy of the
    user configuration, which needs no SQL access management),
  * the same `mpbx_readonly` profile (readonly=2, execution/result/memory limits) and private-network restriction as
    `mpbx_ro`.

The table list comes from the ClickHouse migrations (pbx/migrations/clickhouse): every `CREATE TABLE` whose body has a
`tenant_id UUID` column. Install-wide rows (nil tenant) and other companies' rows are never returned.

Kubernetes (FU-OBS01-L3b): `--k8s` works on deploy/k8s/base/files/clickhouse-company-users.xml, the file the
ClickHouse StatefulSet mounts next to clickhouse-readonly.xml (empty until a company is added); apply it with
`kubectl apply -k` and the StatefulSet rolls. The Grafana side is one command for both: `grafana` creates the
organisation `company-<slug>` and a ClickHouse datasource in it that uses that company's user (Grafana's HTTP API;
organisations cannot be provisioned from files).

Dev sandbox (FU-OBS01-L3c): `--sandbox` works on deploy/compose/clickhouse/users.d/company-users.xml, which the sandbox
ClickHouse (deploy/compose/compose.yaml) mounts next to readonly.xml (empty until a company is added), so the sandbox can
host a company user too. Staff logins: `staff <slug> --url URL --emails FILE` creates one Grafana login per address of the
company's user list (one address per line or comma separated; export it from the console's user list) and adds each as a
Viewer of the organisation `company-<slug>`. Idempotent; a new login gets a random password shown once (it is asked to
change it at the first login), an existing login is only added to the organisation.

usage:
  grafana-company-user.py add    <slug> <company-uuid> [--grafana URL]  # generates a password, shown ONCE; stores its SHA-256 only
  grafana-company-user.py grafana <slug> --url URL      # organisation + datasource; env GRAFANA_ADMIN_PASSWORD, COMPANY_CH_PASSWORD
  grafana-company-user.py staff  <slug> --url URL --emails FILE [--remove-leavers]   # staff logins as Viewers; env GRAFANA_ADMIN_PASSWORD
  grafana-company-user.py remove <slug>
  grafana-company-user.py list
  grafana-company-user.py render                          # rewrite the file from the stored companies (after a migration)
Options: --sandbox (dev sandbox file) | --k8s (Kubernetes base file), --file PATH (default: deploy/compose/prod/clickhouse/company-users.xml), --migrations DIR.
Restart ClickHouse (docker compose restart clickhouse) to apply. Then add a Grafana ClickHouse datasource for the
company with that user (docs/guides/observability.md, "Per-company Grafana").
"""
import argparse
import base64
import hashlib
import json
import os
import re
import secrets
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
DEFAULT_FILE = HERE.parent / "clickhouse" / "company-users.xml"
DEFAULT_MIGRATIONS = ROOT / "pbx" / "migrations" / "clickhouse"
K8S_FILE = ROOT / "deploy" / "k8s" / "base" / "files" / "clickhouse-company-users.xml"
SANDBOX_FILE = ROOT / "deploy" / "compose" / "clickhouse" / "users.d" / "company-users.xml"
DB = "mpbx"
EMAIL_RE = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$")
SLUG_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
NETWORKS = ["127.0.0.1", "::1", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]
EMPTY = "<clickhouse>\n</clickhouse>\n"
USER_RE = re.compile(
    r"<(mpbx_ro_(?P<slug>[a-z0-9_]+))>\s*<!-- company (?P<id>[0-9a-f-]{36}) -->\s*"
    r"<password_sha256_hex>(?P<hash>[0-9a-f]{64})</password_sha256_hex>"
)


def tenant_tables(migrations: Path) -> list[str]:
    """Tables with a `tenant_id UUID` column, in migration order, without duplicates."""
    out: list[str] = []
    for f in sorted(migrations.glob("*.sql")):
        text = re.sub(r"--[^\n]*", "", f.read_text())
        for m in re.finditer(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*ENGINE", text, re.S | re.I):
            name, body = m.group(1), m.group(2)
            if re.search(r"\btenant_id\s+UUID\b", body) and name not in out:
                out.append(name)
    return out


def render(companies: dict[str, tuple[str, str]], tables: list[str]) -> str:
    """companies: slug -> (uuid, sha256 hex of the password)."""
    parts = ["<clickhouse>",
             "  <!-- GENERATED by deploy/compose/prod/scripts/grafana-company-user.py (FU-OBS01-L3). Do not edit; holds password hashes only. -->",
             "  <users>"]
    for slug in sorted(companies):
        cid, digest = companies[slug]
        parts.append(f"    <mpbx_ro_{slug}>")
        parts.append(f"      <!-- company {cid} -->")
        parts.append(f"      <password_sha256_hex>{digest}</password_sha256_hex>")
        parts.append("      <profile>mpbx_readonly</profile>")
        parts.append("      <quota>default</quota>")
        parts.append("      <networks>" + "".join(f"<ip>{n}</ip>" for n in NETWORKS) + "</networks>")
        parts.append("      <grants>")
        for t in tables:
            parts.append(f"        <query>GRANT SELECT ON {DB}.{t}</query>")
        parts.append("      </grants>")
        parts.append("      <databases>")
        parts.append(f"        <{DB}>")
        for t in tables:
            parts.append(f"          <{t}><filter>tenant_id = toUUID('{cid}')</filter></{t}>")
        parts.append(f"        </{DB}>")
        parts.append("      </databases>")
        parts.append(f"    </mpbx_ro_{slug}>")
    parts += ["  </users>", "</clickhouse>", ""]
    return "\n".join(parts) if companies else EMPTY


def load(path: Path) -> dict[str, tuple[str, str]]:
    if not path.exists():
        return {}
    return {m["slug"]: (m["id"], m["hash"]) for m in USER_RE.finditer(path.read_text())}


def save(path: Path, text: str) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(text)
    os.chmod(tmp, 0o644)  # hashes only; ClickHouse (another uid) must read it
    tmp.replace(path)


def grafana_call(url: str, method: str, path: str, auth: str, body: dict | None = None, org: int | None = None):
    """One Grafana HTTP API call: (status, parsed JSON or None). Never raises on an HTTP error status."""
    headers = {"Content-Type": "application/json", "Authorization": "Basic " + base64.b64encode(auth.encode()).decode()}
    if org is not None:
        headers["X-Grafana-Org-Id"] = str(org)
    req = urllib.request.Request(url.rstrip("/") + path, method=method, headers=headers,
                                 data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw) if raw else None
        except ValueError:
            return e.code, None


def grafana_setup(url: str, slug: str, ch_password: str, admin_password: str, ch_host: str, admin_user: str = "admin") -> list[str]:
    """Create the organisation `company-<slug>` and its ClickHouse datasource (idempotent). Returns what was done."""
    auth = f"{admin_user}:{admin_password}"
    org_name = f"company-{slug}"
    done = []
    code, org = grafana_call(url, "GET", "/api/orgs/name/" + org_name, auth)
    if code == 200 and org:
        org_id = org["id"]
        done.append(f"organisation {org_name} exists (id {org_id})")
    elif code == 404:
        code, made = grafana_call(url, "POST", "/api/orgs", auth, {"name": org_name})
        if code != 200 or not made:
            raise RuntimeError(f"could not create the organisation (HTTP {code})")
        org_id = made["orgId"]
        done.append(f"organisation {org_name} created (id {org_id})")
    else:
        raise RuntimeError(f"Grafana answered HTTP {code} for the organisation lookup (check the URL and admin password)")
    ds = {
        "name": "ClickHouse",
        "type": "grafana-clickhouse-datasource",
        "uid": f"mpbx-clickhouse-{slug}",
        "access": "proxy",
        "jsonData": {"host": ch_host, "port": 9000, "protocol": "native", "secure": False,
                     "username": f"mpbx_ro_{slug}", "defaultDatabase": DB},
        "secureJsonData": {"password": ch_password},
    }
    code, _ = grafana_call(url, "POST", "/api/datasources", auth, ds, org=org_id)
    if code == 200:
        done.append(f"datasource ClickHouse created in {org_name} for user mpbx_ro_{slug}")
    elif code == 409:
        done.append(f"datasource ClickHouse already exists in {org_name}; left unchanged")
    else:
        raise RuntimeError(f"could not create the datasource (HTTP {code})")
    return done


def parse_emails(text: str) -> list[str]:
    """Addresses from a list (one per line or comma/semicolon separated; `#` starts a comment), lower-cased, unique, in order."""
    out: list[str] = []
    for line in text.splitlines():
        for tok in re.split(r"[,;\s]+", line.split("#", 1)[0]):
            tok = tok.strip().lower()
            if not tok:
                continue
            if not EMAIL_RE.match(tok):
                raise ValueError(f"not an e-mail address: {tok}")
            if tok not in out:
                out.append(tok)
    return out


def grafana_leavers(url: str, org_id: int, org_name: str, emails: list[str], auth: str, admin_user: str) -> list[str]:
    """Remove from `company-<slug>` every member whose login and e-mail are both missing from the staff list (FU-OBS01-L3d).

    Only the organisation membership is removed: the Grafana login itself is kept (it may belong to another organisation).
    The admin account is never removed, so the operator cannot lock itself out."""
    code, members = grafana_call(url, "GET", f"/api/orgs/{org_id}/users", auth)
    if code != 200 or not isinstance(members, list):
        raise RuntimeError(f"Grafana answered HTTP {code} for the members of {org_name}")
    keep = {e.strip().lower() for e in emails}
    done = []
    for m in members:
        login, mail = str(m.get("login", "")), str(m.get("email", ""))
        if login == admin_user or login.lower() in keep or mail.lower() in keep:
            continue
        code, _ = grafana_call(url, "DELETE", f"/api/orgs/{org_id}/users/{m['userId']}", auth)
        if code != 200:
            raise RuntimeError(f"could not remove {mail or login} from {org_name} (HTTP {code})")
        done.append(f"{mail or login} is not on the staff list; removed from {org_name}")
    return done


def grafana_staff(url: str, slug: str, emails: list[str], admin_password: str, admin_user: str = "admin",
                  remove_leavers: bool = False) -> list[str]:
    """Give each address a Grafana login (created when missing) and make it a Viewer of `company-<slug>`. Idempotent.

    With `remove_leavers`, members of the organisation who are not on the list are removed from it (FU-OBS01-L3d)."""
    auth = f"{admin_user}:{admin_password}"
    org_name = f"company-{slug}"
    code, org = grafana_call(url, "GET", "/api/orgs/name/" + org_name, auth)
    if code == 404:
        raise RuntimeError(f"organisation {org_name} does not exist (run `grafana` first)")
    if code != 200 or not org:
        raise RuntimeError(f"Grafana answered HTTP {code} for the organisation lookup (check the URL and admin password)")
    org_id = org["id"]
    done = []
    for email in emails:
        code, _ = grafana_call(url, "GET", "/api/users/lookup?loginOrEmail=" + urllib.parse.quote(email), auth)
        if code == 404:
            pw = secrets.token_urlsafe(18)
            code, _ = grafana_call(url, "POST", "/api/admin/users", auth, {"name": email, "email": email, "login": email, "password": pw})
            if code != 200:
                raise RuntimeError(f"could not create the login {email} (HTTP {code})")
            done.append(f"login {email} created; password (shown once, to be changed at the first login): {pw}")
        elif code == 200:
            done.append(f"login {email} exists")
        else:
            raise RuntimeError(f"Grafana answered HTTP {code} for the login lookup of {email}")
        code, _ = grafana_call(url, "POST", f"/api/orgs/{org_id}/users", auth, {"loginOrEmail": email, "role": "Viewer"})
        if code == 200:
            done.append(f"{email} added to {org_name} as Viewer")
        elif code == 409:
            done.append(f"{email} is already in {org_name}; left unchanged")
        else:
            raise RuntimeError(f"could not add {email} to {org_name} (HTTP {code})")
    if remove_leavers:
        done += grafana_leavers(url, org_id, org_name, emails, auth, admin_user)
    return done


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", type=Path, default=None)
    ap.add_argument("--k8s", action="store_true", help="work on the Kubernetes base file instead of the Compose one")
    ap.add_argument("--sandbox", action="store_true", help="work on the dev sandbox file (deploy/compose/clickhouse/users.d)")
    ap.add_argument("--migrations", type=Path, default=DEFAULT_MIGRATIONS)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add")
    a.add_argument("slug")
    a.add_argument("company")
    a.add_argument("--grafana", metavar="URL", help="also create the Grafana organisation and datasource at URL")
    g = sub.add_parser("grafana")
    g.add_argument("slug")
    g.add_argument("--url", required=True, help="Grafana base URL")
    st = sub.add_parser("staff")
    st.add_argument("slug")
    st.add_argument("--url", required=True, help="Grafana base URL")
    st.add_argument("--emails", required=True, type=Path, help="file with the company's staff addresses")
    st.add_argument("--remove-leavers", action="store_true",
                    help="also remove from the organisation the members who are not on the list (the login is kept)")
    r = sub.add_parser("remove")
    r.add_argument("slug")
    sub.add_parser("list")
    sub.add_parser("render")
    args = ap.parse_args(argv)
    if args.file is None:
        args.file = K8S_FILE if args.k8s else SANDBOX_FILE if args.sandbox else DEFAULT_FILE
    ch_host = "clickhouse.mpbx.svc" if args.k8s else "clickhouse"

    tables = tenant_tables(args.migrations)
    if not tables:
        print(f"error: no tenant tables found in {args.migrations}", file=sys.stderr)
        return 2
    companies = load(args.file)
    if args.cmd == "list":
        for s, (cid, _) in sorted(companies.items()):
            print(f"mpbx_ro_{s}\t{cid}")
        return 0
    if args.cmd == "staff":
        if args.slug not in companies:
            print("error: no such user (add it first)", file=sys.stderr)
            return 2
        admin_pw = os.environ.get("GRAFANA_ADMIN_PASSWORD", "")
        if not admin_pw:
            print("error: set GRAFANA_ADMIN_PASSWORD", file=sys.stderr)
            return 2
        try:
            emails = parse_emails(args.emails.read_text())
        except (OSError, ValueError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        if not emails:
            print("error: no addresses in the list", file=sys.stderr)
            return 2
        try:
            for line in grafana_staff(args.url, args.slug, emails, admin_pw, os.environ.get("GRAFANA_ADMIN_USER", "admin"),
                                       args.remove_leavers):
                print(line)
        except RuntimeError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1
        return 0
    if args.cmd == "grafana":
        if args.slug not in companies:
            print("error: no such user (add it first)", file=sys.stderr)
            return 2
        admin_pw, ch_pw = os.environ.get("GRAFANA_ADMIN_PASSWORD", ""), os.environ.get("COMPANY_CH_PASSWORD", "")
        if not admin_pw or not ch_pw:
            print("error: set GRAFANA_ADMIN_PASSWORD and COMPANY_CH_PASSWORD (the password `add` printed)", file=sys.stderr)
            return 2
        try:
            for line in grafana_setup(args.url, args.slug, ch_pw, admin_pw, ch_host, os.environ.get("GRAFANA_ADMIN_USER", "admin")):
                print(line)
        except RuntimeError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1
        return 0
    if args.cmd == "add":
        if not SLUG_RE.match(args.slug):
            print("error: slug must match [a-z][a-z0-9_]{0,31}", file=sys.stderr)
            return 2
        try:
            cid = str(uuid.UUID(args.company))
        except ValueError:
            print("error: company must be a UUID", file=sys.stderr)
            return 2
        if cid == "00000000-0000-0000-0000-000000000000":
            print("error: the nil UUID is the install-wide scope, not a company", file=sys.stderr)
            return 2
        if args.slug in companies:
            print(f"error: mpbx_ro_{args.slug} exists (remove it first to rotate)", file=sys.stderr)
            return 2
        pw = secrets.token_urlsafe(24)
        companies[args.slug] = (cid, hashlib.sha256(pw.encode()).hexdigest())
        save(args.file, render(companies, tables))
        print(f"user mpbx_ro_{args.slug} for company {cid}; password (shown once, store it in the Grafana datasource): {pw}")
        if args.grafana:
            admin_pw = os.environ.get("GRAFANA_ADMIN_PASSWORD", "")
            if not admin_pw:
                print("error: --grafana needs GRAFANA_ADMIN_PASSWORD; the user is added, run `grafana` afterwards", file=sys.stderr)
                return 2
            try:
                for line in grafana_setup(args.grafana, args.slug, pw, admin_pw, ch_host, os.environ.get("GRAFANA_ADMIN_USER", "admin")):
                    print(line)
            except RuntimeError as e:
                print(f"error: {e}; the user is added, run `grafana` afterwards", file=sys.stderr)
                return 1
    elif args.cmd == "remove":
        if args.slug not in companies:
            print("error: no such user", file=sys.stderr)
            return 2
        del companies[args.slug]
        save(args.file, render(companies, tables))
    else:
        save(args.file, render(companies, tables))
    print("apply: kubectl apply -k deploy/k8s/overlays/<yours> (the StatefulSet rolls)" if args.k8s
          else "restart the sandbox ClickHouse to apply: docker compose -f deploy/compose/compose.yaml restart clickhouse" if args.sandbox
          else "restart ClickHouse to apply: docker compose restart clickhouse", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
