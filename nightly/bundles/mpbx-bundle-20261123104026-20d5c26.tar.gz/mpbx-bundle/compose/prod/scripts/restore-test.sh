#!/usr/bin/env bash
# Backup -> fresh host -> restore, end to end (W4-DEP-06, PLAT-BAK-003): the acceptance test of
# "restore with the passphrase yields a working PBX; restore without it fails cleanly".
#
#   MPBX_IMAGE=<the mpbx image to test> deploy/compose/prod/scripts/restore-test.sh
#
# What it does, with TWO throw-away Compose projects of this bundle (unique names, random free
# loopback ports, their own volumes and networks; it never touches the dev sandbox project `mpbx`,
# the production default `mpbx-prod`, or any other project):
#
#   install A  `mpbx init`, start, seed (a user, 2000 settings rows, ClickHouse history), sign in,
#              `mpbx backup` to a directory with a random passphrase;
#   install B  a different, fresh `mpbx init` (its own secrets); only the databases are started;
#              a restore with a WRONG passphrase, and one with NO passphrase, fail and change nothing;
#              the restore with the right passphrase loads Postgres and ClickHouse and writes A's
#              identity (master key, JWT and relay keys) into B's .env; then B's `mpbx` starts.
#
# Checks: data identical table by table (Postgres and ClickHouse); B signs in A's user with A's
# password; B's .env holds A's master key id and its own database passwords; B runs as the
# non-superuser owner without BYPASSRLS (row-level security hides rows without a company); the
# backup holds no plaintext secret; and a start of `mpbx` with the master key the fresh install made
# (not restored) is refused by the keyring, which is what the restored master key is for.
# Everything it creates is removed on exit (`docker compose down -v` of its own two projects).
#
# Needs: docker compose v2.24+, curl, python3, openssl >= 3.2 (argon2id), the image in MPBX_IMAGE.
# The images of the bundle are pulled by digest if they are not present. Never prints a secret.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
BUNDLE="$(pwd)"

: "${MPBX_IMAGE:?set MPBX_IMAGE to the mpbx image to test (for example a local build of deploy/docker/mpbx.Dockerfile)}"
SUFFIX="$(python3 -c 'import uuid;print(uuid.uuid4().hex[:8])')"
PA="mpbx-bkp-a-$SUFFIX"; PB="mpbx-bkp-b-$SUFFIX"
WORK="$(mktemp -d)"
KEEP="${KEEP:-0}"

case "$(uname -s)" in
  Linux) NETFILE=compose.linux.yaml ;;
  *)     NETFILE=compose.desktop.yaml ;;
esac
sha256_of() { if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -d' ' -f1; else shasum -a 256 "$1" | cut -d' ' -f1; fi; }
free_port() { python3 -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1])'; }
PORT_A="$(free_port)"; PORT_B="$(free_port)"
UIDGID="$(id -u):$(id -g)"
export MPBX_UID="$(id -u)" MPBX_GID="$(id -g)"

fail=0
ok()  { printf '  ok    %s\n' "$*"; }
bad() { printf '  FAIL  %s\n' "$*"; fail=1; }
check() { local what="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$what"; else bad "$what"; fi; }

# dc <install dir> <project> args...: docker compose for one install.
dc() { local dir="$1" proj="$2"; shift 2; (cd "$dir" && COMPOSE_PROJECT_NAME="$proj" COMPOSE_IGNORE_ORPHANS=true \
        docker compose -f compose.yaml -f "$NETFILE" "$@"); }
dci() { local dir="$1" proj="$2"; shift 2; (cd "$dir" && COMPOSE_PROJECT_NAME="$proj" COMPOSE_IGNORE_ORPHANS=true \
        docker compose -f compose.init.yaml "$@"); }
envval() { sed -n "s/^$2=\(.*\)$/\1/p" "$1/.env" | tail -n1; }

cleanup() {
  if [ "$KEEP" != 1 ]; then
    for p in "A:$PA" "B:$PB"; do
      d="$WORK/${p%%:*}"; [ -d "$d" ] && dc "$d" "${p#*:}" --profile ops down -v --remove-orphans >/dev/null 2>&1 || true
    done
    rm -rf "$WORK"
  else
    echo "KEEP=1: projects $PA and $PB and $WORK were left running"
  fi
}
trap cleanup EXIT

new_install() { # dir port
  local dir="$1" port="$2"
  mkdir -p "$dir"
  cp -R "$BUNDLE/." "$dir/"
  rm -f "$dir/.env"; rm -rf "$dir/backups"
  umask 077
  grep -vE '^(MPBX_IMAGE|MPBX_RTPENGINE_IMAGE|MPBX_HTTP_BIND|MPBX_HTTP_PORT|MPBX_BACKUP_DIR)=' "$BUNDLE/.env.example" > "$dir/.env"
  {
    echo "MPBX_IMAGE=$MPBX_IMAGE"
    echo "MPBX_RTPENGINE_IMAGE=unused/rtpengine-not-started:test"
    echo "MPBX_HTTP_BIND=127.0.0.1"
    echo "MPBX_HTTP_PORT=$port"
    echo "MPBX_BACKUP_DIR=$WORK/backups"
    # compose.linux.yaml interpolates it even though rtpengine is never started here.
    [ "$(uname -s)" != Linux ] || echo "RTPE_INTERFACE=127.0.0.1"
  } >> "$dir/.env"
  chmod 600 "$dir/.env"
}

echo "== install A ($PA, port $PORT_A) and install B ($PB, port $PORT_B)"
mkdir -p "$WORK/backups"
new_install "$WORK/A" "$PORT_A"
new_install "$WORK/B" "$PORT_B"
openssl rand -base64 24 | tr -d '/+=\n' > "$WORK/pass.right"; printf -- '-pbx' >> "$WORK/pass.right"
openssl rand -base64 24 | tr -d '/+=\n' > "$WORK/pass.wrong"; printf -- '-pbx' >> "$WORK/pass.wrong"
chmod 600 "$WORK/pass.right" "$WORK/pass.wrong"

dci "$WORK/A" "$PA" run --rm -T init >/dev/null 2>&1 && ok "A: mpbx init" || bad "A: mpbx init"
dci "$WORK/B" "$PB" run --rm -T init >/dev/null 2>&1 && ok "B: mpbx init (a different install: its own secrets)" || bad "B: mpbx init"
[ "$(envval "$WORK/A" MPBX_MASTER_KEY_ID)" != "$(envval "$WORK/B" MPBX_MASTER_KEY_ID)" ] \
  && ok "A and B have different master keys" || bad "A and B share a master key"
A_MASTER_ID="$(envval "$WORK/A" MPBX_MASTER_KEY_ID)"
B_FRESH_MASTER_ID="$(envval "$WORK/B" MPBX_MASTER_KEY_ID)"
B_FRESH_MASTER_KEY="$(envval "$WORK/B" MPBX_MASTER_KEY)"   # for the negative control only; never printed

echo "== A: start and seed"
dc "$WORK/A" "$PA" up -d --wait postgres valkey clickhouse mpbx >/dev/null 2>&1 && ok "A: postgres, valkey, clickhouse and mpbx are healthy" || { bad "A did not start"; dc "$WORK/A" "$PA" logs --tail 30 mpbx 2>&1 | tail -30; exit 1; }
psql_a() { dc "$WORK/A" "$PA" exec -T postgres psql -U mpbx_admin -d mpbx -v ON_ERROR_STOP=1 -tA "$@"; }
psql_b() { dc "$WORK/B" "$PB" exec -T postgres psql -U mpbx_admin -d mpbx -v ON_ERROR_STOP=1 -tA "$@"; }

pw="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)-Aa1"
saltb="$(openssl rand -hex 16)"
hashb="$(openssl kdf -keylen 32 -kdfopt "pass:$pw" -kdfopt "hexsalt:$saltb" -kdfopt iter:2 -kdfopt memcost:19456 -kdfopt lanes:1 -kdfopt threads:1 -binary ARGON2ID | openssl base64 -A | tr -d '=')"
salt64="$(printf '%s' "$saltb" | xxd -r -p | openssl base64 -A | tr -d '=')"
phc="\$argon2id\$v=19\$m=19456,t=2,p=1\$${salt64}\$${hashb}"
email="restore-$(openssl rand -hex 4)@example.test"
tenant=01900000-0000-7000-8000-000000000001
uid="$(python3 -c 'import os, time, uuid; b = bytearray(os.urandom(16)); b[0:6] = int(time.time() * 1000).to_bytes(6, "big"); b[6] = 0x70 | (b[6] & 0x0F); b[8] = 0x80 | (b[8] & 0x3F); print(uuid.UUID(bytes=bytes(b)))')"
dc "$WORK/A" "$PA" exec -T postgres psql -U mpbx_admin -d mpbx -v ON_ERROR_STOP=1 -q >/dev/null <<SQL
INSERT INTO users (id, tenant_id, email, first_name, last_name) VALUES ('$uid', '$tenant', '$email', 'Restore', E'Tab\\tNew\\nline \\\\ Ünï');
INSERT INTO user_credentials (tenant_id, user_id, password_hash, password_changed_at) VALUES ('$tenant', '$uid', '$phc', now());
INSERT INTO system_settings (key, value) SELECT 'bulk.' || g, jsonb_build_object('n', g, 'pad', repeat('x', 100)) FROM generate_series(1, 2000) g;
SQL
ok "A: seeded a user (with awkward characters) and 2000 settings rows"
chq_a() { dc "$WORK/A" "$PA" exec -T clickhouse sh -c "clickhouse-client --user mpbx --password \"\$CLICKHOUSE_PASSWORD\" -d mpbx -q \"$1\""; }
chq_b() { dc "$WORK/B" "$PB" exec -T clickhouse sh -c "clickhouse-client --user mpbx --password \"\$CLICKHOUSE_PASSWORD\" -d mpbx -q \"$1\""; }
chq_a "INSERT INTO cdr_calls (tenant_id, call_id, version, start_time, direction, caller_raw, callee_raw, talk_ms, tags) SELECT toUUID('$tenant'), generateUUIDv4(), 1, now64(3) - toIntervalSecond(number), 'inbound', concat('+1555', toString(number)), '1001', toUInt32(number), ['a','b'] FROM numbers(5000)"
ok "A: seeded 5000 CDRs"
base_a="http://127.0.0.1:$PORT_A"; base_b="http://127.0.0.1:$PORT_B"
login() { # base -> prints the access token and the refresh token (two lines) or fails
  python3 - "$1" "$email" "$pw" <<'PY'
import json, sys, urllib.request
base, email, pw = sys.argv[1:4]
req = urllib.request.Request(base + "/api/v1/auth/login", data=json.dumps({"email": email, "password": pw, "client": "restore-test"}).encode(),
                             headers={"content-type": "application/json"})
d = json.load(urllib.request.urlopen(req, timeout=20))
print(d["access_token"]); print(d["refresh_token"])
PY
}
login_a="$(login "$base_a")" && ok "A: the user signs in" || bad "A: sign-in failed"
token_a="$(printf "%s" "$login_a" | sed -n 1p)"; refresh_a="$(printf "%s" "$login_a" | sed -n 2p)"

digest_pg() { # psql function name
  "$1" -c "select string_agg(format('%s=%s', t, c), ' ' order by t) from (
      select 'users' t, md5(coalesce(string_agg(x::text, '|' order by x::text), '')) c from users x
      union all select 'user_credentials', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from user_credentials x
      union all select 'system_settings', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from system_settings x
      union all select 'tenants', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from tenants x
      union all select 'roles', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from roles x
      union all select 'secret_master_key', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from secret_master_key x
      union all select 'secret_data_keys', md5(coalesce(string_agg(x::text, '|' order by x::text), '')) from secret_data_keys x) s"
}
digest_ch() {
  "$1" "SELECT concat(toString(count()), ':', toString(groupBitXor(cityHash64(toString(tuple(*)))))) FROM cdr_calls"
}

echo "== A: back up"
dc "$WORK/A" "$PA" run --rm -T --user "$UIDGID" -v "$WORK/pass.right:/run/backup.pass:ro" mpbx-ops backup --passphrase-file /run/backup.pass --prune --json > "$WORK/backup.json" 2> "$WORK/backup.err" \
  && ok "A: mpbx backup (Postgres, ClickHouse, secrets, config) to $WORK/backups" || { bad "A: mpbx backup failed"; sed 's/^/    /' "$WORK/backup.err" | tail -5; exit 1; }
BACKUP_ID="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["id"])' "$WORK/backup.json")"
ok "A: backup $BACKUP_ID"
DIGEST_A="$(digest_pg psql_a)"; CH_A="$(digest_ch chq_a)"
dir="$WORK/backups/backups/$BACKUP_ID"
python3 - "$dir" "$(envval "$WORK/A" MPBX_MASTER_KEY)" "$(envval "$WORK/A" POSTGRES_PASSWORD)" "$email" <<'PY' && ok "the backup holds no plaintext secret, password or e-mail address" || bad "the backup leaks plaintext"
import os, sys
d, *needles = sys.argv[1:]
for f in os.listdir(d):
    if f == "manifest.json":
        continue
    data = open(os.path.join(d, f), "rb").read()
    for n in needles + ["postgres", "MPBX_MASTER_KEY"]:
        assert n.encode() not in data, (f, "leaks")
m = open(os.path.join(d, "manifest.json")).read()
assert needles[0] not in m and needles[1] not in m
PY
ls "$dir" | tr '\n' ' ' | sed 's/^/    parts: /'; echo
check "the backup is verified from outside the app (hashes, no passphrase)" \
  dc "$WORK/A" "$PA" run --rm -T --user "$UIDGID" mpbx-ops backup verify latest
check "the backup is verified in full with the passphrase" \
  dc "$WORK/A" "$PA" run --rm -T --user "$UIDGID" -v "$WORK/pass.right:/run/backup.pass:ro" mpbx-ops backup verify latest --passphrase-file /run/backup.pass

echo "== B: a fresh host; only the databases are started"
dc "$WORK/B" "$PB" up -d --wait postgres valkey clickhouse >/dev/null 2>&1 && ok "B: postgres, valkey and clickhouse are healthy" || { bad "B did not start"; exit 1; }
ENV_B_BEFORE="$(sha256_of "$WORK/B/.env")"
restore_b() { # extra args
  dc "$WORK/B" "$PB" run --rm -T --user "$UIDGID" -v "$WORK/B:/work" "$@"
}
state_b() { psql_b -c "select coalesce(to_regclass('public.users')::text, 'no-schema')"; }
[ "$(state_b)" = no-schema ] && ok "B: the database is empty (not even migrated)" || bad "B is not fresh"

echo "== B: restore with the WRONG passphrase, and with NONE: fails cleanly, changes nothing"
out="$(restore_b -v "$WORK/pass.wrong:/run/backup.pass:ro" mpbx-ops restore latest --passphrase-file /run/backup.pass --sink env-file:/work/.env 2>&1)" && rc=0 || rc=$?
[ "$rc" != 0 ] && echo "$out" | grep -q 'MPBX-BACKUP-PASSPHRASE-WRONG' && ok "wrong passphrase: refused with MPBX-BACKUP-PASSPHRASE-WRONG (exit $rc)" || bad "wrong passphrase: exit $rc: $(echo "$out" | tail -2)"
out="$(restore_b mpbx-ops restore latest --sink env-file:/work/.env 2>&1)" && rc=0 || rc=$?
[ "$rc" != 0 ] && echo "$out" | grep -q 'MPBX-BACKUP-PASSPHRASE-MISSING' && ok "no passphrase: refused with MPBX-BACKUP-PASSPHRASE-MISSING (exit $rc)" || bad "no passphrase: exit $rc: $(echo "$out" | tail -2)"
[ "$(sha256_of "$WORK/B/.env")" = "$ENV_B_BEFORE" ] && ok "B: .env unchanged" || bad "B: .env changed"
[ "$(state_b)" = no-schema ] && ok "B: the database is untouched" || bad "B: the database changed"

echo "== B: dry run, then the real restore with the right passphrase"
restore_b -v "$WORK/pass.right:/run/backup.pass:ro" mpbx-ops restore latest --passphrase-file /run/backup.pass --dry-run >/dev/null 2>&1 \
  && ok "dry run: the passphrase opens the backup and every part is intact" || bad "dry run failed"
restore_b -v "$WORK/pass.right:/run/backup.pass:ro" mpbx-ops restore latest --passphrase-file /run/backup.pass --sink env-file:/work/.env --extract-config /work/restored-config > "$WORK/restore.out" 2>&1 \
  && ok "mpbx restore finished" || { bad "mpbx restore failed"; tail -8 "$WORK/restore.out" | sed 's/^/    /'; exit 1; }
sed 's/^/    /' "$WORK/restore.out" | grep -E "Restored|Postgres|ClickHouse|Secrets written|Config" | head -6
[ "$(envval "$WORK/B" MPBX_MASTER_KEY_ID)" = "$A_MASTER_ID" ] && ok "B's .env now holds A's master key (id $A_MASTER_ID)" || bad "B's master key was not restored"
[ "$(envval "$WORK/B" MPBX_JWT_KID)" = "$(envval "$WORK/A" MPBX_JWT_KID)" ] && ok "B's .env holds A's JWT signing key" || bad "JWT key not restored"
[ "$(envval "$WORK/B" POSTGRES_PASSWORD)" != "$(envval "$WORK/A" POSTGRES_PASSWORD)" ] && ok "B kept its own database passwords" || bad "B's database password was replaced"
[ "$(stat -f '%Lp' "$WORK/B/.env" 2>/dev/null || stat -c '%a' "$WORK/B/.env")" = 600 ] && ok "B's .env is mode 0600" || bad "B's .env is not 0600"
ls "$WORK/B/restored-config" >/dev/null 2>&1 && ok "the config part was extracted for review" || bad "no config extracted"

echo "== B: the data is the data of A"
[ "$(digest_pg psql_b)" = "$DIGEST_A" ] && ok "Postgres: users, credentials, settings, tenants, roles, master key row and data keys are identical" || { bad "Postgres differs"; echo "A: $DIGEST_A"; echo "B: $(digest_pg psql_b)"; }
[ "$(digest_ch chq_b)" = "$CH_A" ] && ok "ClickHouse: 5000 CDRs identical (count and hash $CH_A)" || bad "ClickHouse differs: $(digest_ch chq_b) vs $CH_A"

echo "== B: start the PBX with the restored secrets"
dc "$WORK/B" "$PB" up -d --wait mpbx >/dev/null 2>&1 && ok "B: mpbx is healthy (the keyring accepted the restored master key)" || { bad "B: mpbx did not become healthy"; dc "$WORK/B" "$PB" logs --tail 20 mpbx 2>&1 | tail -20; }
login_b="$(login "$base_b")" && ok "B: A's user signs in with A's password" || bad "B: sign-in failed"
token_b="$(printf "%s" "$login_b" | sed -n 1p)"
check "B: GET /api/v1/me with B's token" curl -fsS "$base_b/api/v1/me" -H "authorization: Bearer ${token_b:-x}"
# The JWT signing key came back with the backup, so an access token A issued still verifies on B until it
# expires; the sessions did not, so A's refresh token is dead: everyone signs in again.
check "B: an access token signed by A verifies (the JWT key was restored)" \
  curl -fsS "$base_b/api/v1/me" -H "authorization: Bearer ${token_a:-x}"
code="$(curl -sS -o /dev/null -w '%{http_code}' -X POST "$base_b/api/v1/auth/refresh" -H 'content-type: application/json' \
  -d "{\"refresh_token\": \"${refresh_a:-x}\"}" || true)"
[ "$code" = 401 ] && ok "B: A's refresh token is refused (401): sessions are not restored" || bad "B: A's refresh token answered $code"
check "B: the application role is not a superuser and has no BYPASSRLS" \
  test "$(psql_b -c "select rolsuper::text || rolbypassrls::text from pg_roles where rolname = 'mpbx'")" = falsefalse
check "B: row-level security is back (FORCE) on the tenant tables" \
  test "$(psql_b -c "select count(*) from pg_class where relforcerowsecurity and relname = 'users'")" = 1
check "B: no trigger was left disabled by the restore" \
  test "$(psql_b -c "select count(*) from pg_trigger where not tgisinternal and tgenabled <> 'O'")" = 0
check "B: the restore left an audit record in the restored install" \
  test "$(psql_b -c "select count(*) from system_outbox where payload::text like '%backup.restored%'")" -ge 1

echo "== negative control: the master key is what makes the restored data readable"
# Start a second mpbx container on B's network with the master key the FRESH install generated (not restored).
# Its keyring must refuse to open the restored database.
nc_out="$(dc "$WORK/B" "$PB" run --rm -T --no-deps -e MPBX_MASTER_KEY="$B_FRESH_MASTER_KEY" \
  -e MPBX_MASTER_KEY_ID="$B_FRESH_MASTER_ID" -e MPBX__HTTP__LISTEN=127.0.0.1:18080 -e MPBX__METRICS__LISTEN=127.0.0.1:19464 mpbx-ops run 2>&1 || true)"
echo "$nc_out" | grep -q 'MPBX-SECRETS-WRONG-MASTER-KEY' && ok "the key B generated for itself is refused: it is not the key the restored data is encrypted with" || bad "the fresh install's own master key was accepted: $(echo "$nc_out" | tail -2)"

echo
if [ "$fail" = 0 ]; then echo "restore-test: PASS"; else echo "restore-test: FAIL"; fi
exit "$fail"
