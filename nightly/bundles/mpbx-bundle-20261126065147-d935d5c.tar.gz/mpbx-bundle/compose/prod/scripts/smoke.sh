#!/usr/bin/env bash
# Smoke test of the production Compose bundle (W4-DEP-02): run it against a started project.
#
#   COMPOSE_PROJECT_NAME=mpbx-smoke COMPOSE_FILE=compose.yaml:compose.desktop.yaml scripts/smoke.sh
#
# Checks: every container is running and healthy, the databases publish nothing and sit on an internal
# network, the application logs in to Postgres as a non-superuser without BYPASSRLS (and the superuser cannot
# log in over the network), the ClickHouse read-only user cannot read `system`, and the first System Owner is
# created through the real setup API (W4-WEB-06, FU-DEP02-L2): the script issues a fresh single-use setup token
# the way `mpbx-ctl setup-url` does (only its SHA-256 goes into .env, mpbx is recreated to read it), creates the
# owner with a random password (never printed) and a TOTP authenticator, checks that the token is spent, and
# signs in with password and code. On a project whose setup is already done it checks that the setup link is
# refused instead (the sign-in checks need a fresh project). Needs: docker compose, curl, python3, openssl on the
# host. Never prints a secret.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

fail=0
ok()  { printf '  ok    %s\n' "$*"; }
bad() { printf '  FAIL  %s\n' "$*"; fail=1; }
check() { local what="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$what"; else bad "$what"; fi; }

dc() { docker compose "$@"; }
envval() { sed -n "s/^$1=\(.*\)$/\1/p" .env | tail -n1; }
PORT="$(envval MPBX_HTTP_PORT)"; PORT="${PORT:-8080}"
BIND="$(envval MPBX_HTTP_BIND)"; BIND="${BIND:-127.0.0.1}"
[ "$BIND" != 0.0.0.0 ] || BIND=127.0.0.1

echo "== containers"
python3 - "$(dc ps -a --format json | tr '\n' ',')" <<'PY' && ok "all containers running and healthy" || bad "some container is not running/healthy"
import json, sys
rows = json.loads("[" + sys.argv[1].rstrip(",") + "]")
bad = [(r["Service"], r["State"], r.get("Health", "")) for r in rows
       if r["State"] != "running" or r.get("Health", "healthy") not in ("healthy", "")]
for b in bad:
    print("   ", b)
print("    services:", ", ".join(sorted(r["Service"] for r in rows)))
sys.exit(1 if bad else 0)
PY

echo "== networking"
python3 - "$(dc ps -a --format json | tr '\n' ',')" <<'PY' && ok "postgres, valkey and clickhouse publish no ports" || bad "a database publishes a port"
import json, sys
rows = json.loads("[" + sys.argv[1].rstrip(",") + "]")
leaks = [(r["Service"], r["Publishers"]) for r in rows
         if r["Service"] in ("postgres", "valkey", "clickhouse") and any(p.get("PublishedPort") for p in (r.get("Publishers") or []))]
print("   ", leaks) if leaks else None
sys.exit(1 if leaks else 0)
PY
proj="${COMPOSE_PROJECT_NAME:-mpbx-prod}"
check "network ${proj}_data is internal" test "$(docker network inspect "${proj}_data" --format '{{.Internal}}')" = true
for s in postgres valkey clickhouse; do
  id="$(dc ps -q "$s")"
  nets="$(docker inspect "$id" --format '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}')"
  check "$s is only on ${proj}_data" test "$(echo $nets)" = "${proj}_data"
done

echo "== postgres roles"
psql_app() { dc exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" psql -h 127.0.0.1 -U mpbx -d mpbx -v ON_ERROR_STOP=1 -tA'; }
check "application role is not superuser and has no BYPASSRLS" \
  test "$(echo "select rolsuper::text || rolbypassrls::text || rolcanlogin::text from pg_roles where rolname = 'mpbx'" | psql_app)" = "falsefalsetrue"
check "superuser cannot log in over the network (no password)" \
  test "$(echo "select rolpassword is null from pg_authid where rolname = 'mpbx_admin'" | dc exec -T postgres psql -U mpbx_admin -d postgres -tA)" = t
# Not 127.0.0.1: the image trusts loopback inside the container (same as `exec`); the container's own network
# address is what other containers would connect to.
if dc exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$(hostname -i | cut -d" " -f1)" -U mpbx_admin -d postgres -tAc "select 1"' >/dev/null 2>&1; then
  bad "superuser mpbx_admin logged in over TCP with the application password"
else
  ok "superuser mpbx_admin is refused over TCP"
fi

echo "== first System Owner through the setup API (W4-WEB-06)"
base="http://$BIND:$PORT"
check "GET /api/v1/version" curl -fsS "$base/api/v1/version"
stage="$(curl -fsS "$base/api/v1/setup" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("stage", ""))' 2>/dev/null || true)"
if [ "$stage" = owner_required ]; then
  # A fresh single-use token, like `mpbx-ctl setup-url`: the token stays in this shell, only its hash is stored.
  token="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
  hash="$(printf '%s' "$token" | openssl dgst -sha256 -r | cut -d' ' -f1)"
  tmp="$(mktemp .env.XXXXXX)"
  chmod 600 "$tmp"
  grep -vE '^MPBX_SETUP_TOKEN_(SHA256|EXPIRES_AT)=' .env >"$tmp" || true
  printf 'MPBX_SETUP_TOKEN_SHA256=%s\nMPBX_SETUP_TOKEN_EXPIRES_AT=%s\n' "$hash" "$(( $(date +%s) + 3600 ))" >>"$tmp"
  mv "$tmp" .env
  if dc up -d --wait mpbx >/dev/null 2>&1; then
    ok "mpbx restarted with a new setup token hash"
    pw="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)-Aa1"
    email="smoke-$(openssl rand -hex 4)@example.test"
    if MPBX_SETUP_TOKEN="$token" MPBX_OWNER_PASSWORD="$pw" python3 scripts/first-owner.py "$base" "$email"; then
      ok "the System Owner was created with the setup link, which is now spent"
    else
      bad "the setup API checks failed (see above)"
    fi
    check "row-level security hides users without a company set (owner is not exempt)" \
      test "$(echo "select count(*) from users" | psql_app)" = 0
  else
    bad "mpbx did not come back after the setup token change"
  fi
  unset token pw
else
  echo "  skip  setup is already done on this project (stage: ${stage:-unknown}); the sign-in checks need a fresh project"
  code="$(curl -sS -o /dev/null -w '%{http_code}' -X POST "$base/api/v1/setup/owner" -H 'content-type: application/json' \
    -d '{"token":"not-the-token-0000000000","email":"x@example.test","first_name":"X","password":"x"}')"
  case "$code" in 401|409) ok "the setup link creates no second owner ($code)" ;; *) bad "setup owner route answered $code" ;; esac
fi

echo "== clickhouse"
chq() { dc exec -T clickhouse sh -c "clickhouse-client --user mpbx_ro --password \"\$CLICKHOUSE_RO_PASSWORD\" -q \"$1\""; }
check "read-only user reads the mpbx database" chq "select count() from system.tables where database = 'mpbx'"
if chq "select count() from system.users" >/dev/null 2>&1; then bad "read-only user can read system.users"; else ok "read-only user cannot read system.users"; fi
if chq "create table mpbx.should_not_exist (x UInt8) engine = Memory" >/dev/null 2>&1; then bad "read-only user can create tables"; else ok "read-only user cannot write"; fi
# The Grafana plugin sends max_execution_time with every query: readonly=1 rejects that, readonly=2 allows it (W4-OBS-01).
check "read-only user may set per-query limits (what the Grafana plugin does)" chq "select 1 settings max_execution_time = 20"
if chq "select 1 settings max_execution_time = 100000" >/dev/null 2>&1; then bad "read-only user can raise max_execution_time past its constraint"; else ok "read-only user cannot lift its execution-time limit"; fi
# 0 means unlimited in ClickHouse: <max> alone lets the user set it, so every limit is also tested at 0.
for lim in max_execution_time max_result_rows max_memory_usage; do
  if chq "select 1 settings $lim = 0" >/dev/null 2>&1; then bad "read-only user can set $lim = 0 (unlimited)"; else ok "read-only user cannot set $lim = 0"; fi
done
if chq "select 1 settings max_result_rows = 100000000" >/dev/null 2>&1; then bad "read-only user can raise max_result_rows past its constraint"; else ok "read-only user cannot raise max_result_rows"; fi
if chq "select 1 settings max_memory_usage = 99000000000" >/dev/null 2>&1; then bad "read-only user can raise max_memory_usage"; else ok "read-only user cannot change max_memory_usage"; fi
if chq "insert into mpbx.cdr_calls (call_id) values (generateUUIDv4())" >/dev/null 2>&1; then bad "read-only user can insert"; else ok "read-only user cannot insert"; fi

echo "== observability (profile observability; skipped when Grafana is not running)"
if [ -n "$(dc ps -q grafana 2>/dev/null)" ]; then
  gport="$(envval GRAFANA_PORT)"; gport="${gport:-3000}"
  gcurl() { printf 'user = "admin:%s"\n' "$(envval GRAFANA_ADMIN_PASSWORD)" | curl -fsS -K - "http://127.0.0.1:$gport$1"; }
  check "Grafana is healthy" gcurl /api/health
  check "Prometheus datasource works" gcurl /api/datasources/uid/mpbx-prometheus/health
  check "ClickHouse datasource works (read-only user, official plugin)" gcurl /api/datasources/uid/mpbx-clickhouse/health
  check "eight MonoPbx dashboards are provisioned" test "$(gcurl '/api/search?tag=monopbx' | python3 -c 'import json,sys; print(len(json.load(sys.stdin)))')" = 8
  check "Grafana is not reachable without a login" test "$(curl -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1:$gport/api/search")" = 401
  check "Prometheus scrapes mpbx" test "$(dc exec -T prometheus wget -qO- 'http://127.0.0.1:9090/api/v1/targets?state=active' | python3 -c 'import json,sys; print(sum(1 for t in json.load(sys.stdin)["data"]["activeTargets"] if t["labels"]["job"]=="mpbx"))')" -ge 1
else
  echo "  skip  no grafana container (enable COMPOSE_PROFILES=observability)"
fi

echo
if [ "$fail" = 0 ]; then echo "smoke: PASS"; else echo "smoke: FAIL"; fi
exit "$fail"
