#!/usr/bin/env python3
"""Create the first System Owner through the real setup API (W4-WEB-06), the way the setup
wizard does, and check that the setup link is spent afterwards. Used by smoke.sh (FU-DEP02-L2:
no more seeding a user as the database superuser).

    MPBX_SETUP_TOKEN=... MPBX_OWNER_PASSWORD=... first-owner.py <base url> <e-mail>

The token and the password come from the environment (never the command line, where `ps` would
show them). The token, the password, the TOTP secret and the recovery codes are never printed.
Exit code 0 when every check passed. Python 3 standard library only.
"""

import base64
import hashlib
import hmac
import json
import struct
import sys
import time
import urllib.error
import urllib.request

fail = 0


def ok(msg):
    print(f"  ok    {msg}")


def bad(msg):
    global fail
    print(f"  FAIL  {msg}")
    fail = 1


def call(base, method, path, body=None, bearer=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(base + path, data=data, method=method)
    if data is not None:
        req.add_header("content-type", "application/json")
    if bearer:
        req.add_header("authorization", "Bearer " + bearer)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except ValueError:
            return e.code, {}


def totp(secret_b32, at=None):
    s = secret_b32.replace(" ", "").upper()
    key = base64.b32decode(s + "=" * (-len(s) % 8))
    step = int((time.time() if at is None else at) // 30)
    mac = hmac.new(key, struct.pack(">Q", step), hashlib.sha1).digest()
    o = mac[-1] & 0x0F
    n = (struct.unpack(">I", mac[o:o + 4])[0] & 0x7FFFFFFF) % 1_000_000
    return f"{n:06d}"


def next_step():
    """Wait for the next 30-second step: a TOTP code is accepted once."""
    time.sleep(30 - time.time() % 30 + 1)


def main():
    import os
    token = os.environ.get("MPBX_SETUP_TOKEN", "")
    password = os.environ.get("MPBX_OWNER_PASSWORD", "")
    if len(sys.argv) != 3 or not token or not password:
        print(__doc__, file=sys.stderr)
        return 2
    base, email = sys.argv[1:3]

    st, s = call(base, "GET", "/api/v1/setup")
    if st != 200:
        bad(f"GET /api/v1/setup -> {st}")
        return 1
    if s.get("stage") != "owner_required":
        bad(f"setup stage is {s.get('stage')!r}, not owner_required (run the smoke on a fresh project)")
        return 1
    ok("GET /api/v1/setup -> owner_required (no default administrator exists)")

    st, b = call(base, "POST", "/api/v1/setup/token", {"token": token[:-1] + ("A" if token[-1] != "A" else "B")})
    if st == 401 and b.get("code") == "MPBX-SETUP-TOKEN-INVALID":
        ok("a wrong setup token is refused (401)")
    else:
        bad(f"wrong setup token answered {st} {b.get('code')}")

    st, b = call(base, "POST", "/api/v1/setup/owner", {
        "token": token, "email": email, "first_name": "Smoke", "last_name": "Owner", "password": password})
    if st != 201 or not b.get("secret"):
        bad(f"POST /api/v1/setup/owner -> {st} {b.get('code')}")
        return 1
    secret = b["secret"]
    ok("POST /api/v1/setup/owner -> 201 (owner waits for its authenticator)")

    st, b = call(base, "POST", "/api/v1/auth/login", {"email": email, "password": password})
    if st == 401:
        ok("the waiting owner cannot sign in with the password alone (401)")
    else:
        bad(f"waiting owner login answered {st}")

    st, b = call(base, "POST", "/api/v1/setup/owner/confirm", {
        "token": token, "email": email, "password": password, "code": totp(secret)})
    if st != 200 or not b.get("access_token") or len(b.get("recovery_codes", [])) != 10:
        bad(f"POST /api/v1/setup/owner/confirm -> {st} {b.get('code')}")
        return 1
    ok("POST /api/v1/setup/owner/confirm -> 200 (session, 10 recovery codes)")
    system = b["access_token"]

    st, b = call(base, "GET", "/api/v1/me", bearer=system)
    if st == 200 and any(p.get("key") == "system.settings:write" for p in b.get("permissions", [])):
        ok("GET /api/v1/me with the owner's session -> the System Owner permissions")
    else:
        bad(f"GET /api/v1/me (owner session) -> {st}")

    for path, body in (("/api/v1/setup/token", {"token": token}),
                       ("/api/v1/setup/owner", {"token": token, "email": "second@example.test",
                                                 "first_name": "Second", "password": password})):
        st, b = call(base, "POST", path, body)
        if st == 409 and b.get("code") == "MPBX-SETUP-COMPLETE":
            ok(f"POST {path} after the confirmation -> 409 MPBX-SETUP-COMPLETE (token spent)")
        else:
            bad(f"POST {path} after the confirmation -> {st} {b.get('code')}")

    st, b = call(base, "PUT", "/api/v1/setup/extension", {"number": "1000"}, bearer=system)
    if st == 200:
        ok("PUT /api/v1/setup/extension -> 200 (the administrator's extension)")
    else:
        bad(f"PUT /api/v1/setup/extension -> {st} {b.get('code')}")

    st, b = call(base, "POST", "/api/v1/setup/finish", bearer=system)
    if st == 204:
        ok("POST /api/v1/setup/finish -> 204")
    else:
        bad(f"POST /api/v1/setup/finish -> {st} {b.get('code')}")

    st, b = call(base, "POST", "/api/v1/auth/login", {"email": email, "password": password})
    if st == 401 and b.get("code") == "MPBX-AUTH-TOTP-REQUIRED":
        ok("sign-in asks for the authenticator code")
    else:
        bad(f"login without a code answered {st} {b.get('code')}")
    next_step()
    st, b = call(base, "POST", "/api/v1/auth/login", {"email": email, "password": password, "totp_code": totp(secret)})
    if st == 200 and b.get("access_token"):
        ok("POST /api/v1/auth/login with the TOTP code -> 200")
        st, _ = call(base, "GET", "/api/v1/me", bearer=b["access_token"])
        (ok if st == 200 else bad)(f"GET /api/v1/me with the token -> {st}")
    else:
        bad(f"login with the code answered {st} {b.get('code')}")
    st, b = call(base, "POST", "/api/v1/auth/login", {"email": email, "password": "definitely-wrong-password"})
    (ok if st == 401 else bad)(f"a wrong password is refused ({st})")
    return fail


if __name__ == "__main__":
    sys.exit(main())
