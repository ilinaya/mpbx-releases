# MonoPbx Docker Compose, production bundle (W4-DEP-02)

The shipped Compose bundle: the production images of W4-DEP-01 (`mpbx`, `mpbx-rtpengine`, `mpbx-media`),
Postgres, Valkey and ClickHouse, with optional coturn and observability. ARCHITECTURE 14.3, DECISIONS Round 7.
The dev sandbox (`make dev`, one directory up) is a different thing: it builds simulators, publishes the databases on
loopback and uses throwaway secrets. Never use it in production.

## Install

Requirements: Docker Engine 24+ with the Compose plugin (v2.24+), Linux (Ubuntu 24.04 LTS is the supported host).

```sh
cd deploy/compose/prod
cp .env.example .env            # set MPBX_IMAGE and MPBX_RTPENGINE_IMAGE (pin by digest), MPBX_PUBLIC_URL, ports
./start.sh                      # = the three commands below
```

```sh
docker compose -f compose.init.yaml run --rm init                      # 1. mpbx init: secrets into .env, recovery key shown ONCE
docker compose -f compose.yaml -f compose.linux.yaml up -d --wait      # 2. start (Docker Desktop: compose.desktop.yaml, dev/trial only)
scripts/smoke.sh                                                       # 3. optional: health, isolation and login checks
```

**Write the recovery key down when `mpbx init` shows it** (password manager or paper). It is not stored anywhere on the
host; without it, a lost `.env` means lost trunk passwords, API keys and encrypted recordings (DECISIONS Round 5).
In a terminal, `init` shows the key before it writes anything and asks you to re-type one group. Without a terminal
(`run -T`, CI) it prints the key once to stdout after storing the secrets: do not keep that output. Open the
single-use setup URL it prints to create the first administrator: the setup wizard (W4-WEB-06,
[guide](../../../docs/guides/setup-wizard.md)) creates the System Owner with a password and an authenticator app and
spends the link.

Back up `.env` (mode 0600, git-ignored) together with the volumes. Running `init` again changes nothing.

## What runs

| Service | Image | Profile | Network | Published |
|---|---|---|---|---|
| `postgres` | `postgres:17-alpine@sha256:...` | default | `data` (internal) | nothing |
| `valkey` | `valkey/valkey:8-alpine@sha256:...` | default | `data` | nothing |
| `clickhouse` | `clickhouse-server:25.8-alpine@sha256:...` | default | `data` | nothing |
| `mpbx` | `MPBX_IMAGE` (API, embedded web client; role `api` on Linux, `all` on Docker Desktop) | default | `data`, `edge` | `MPBX_HTTP_BIND:MPBX_HTTP_PORT` (default `0.0.0.0:8080`) |
| `rtpengine` | `MPBX_RTPENGINE_IMAGE` (stock upstream, userspace forwarding) | default | **host** on Linux | UDP `RTPE_PORT_MIN-MAX` (default 30000-40000 = 2,500 calls, 4 ports per call; see below) on the host |
| `coturn` | `coturn/coturn:4.12.0@sha256:...` | `turn` | **host** on Linux | 3478, `TURN_MIN_PORT-MAX` |
| `prometheus`, `grafana` | pinned | `observability` | `data` (+ `edge` for Grafana) | Grafana on `127.0.0.1:GRAFANA_PORT` only |
| `mpbx-media` | `MPBX_MEDIA_IMAGE` | `media` | `data`, `edge` | nothing |
| `mpbx-sip` (Linux file) | `MPBX_IMAGE`, `run --role all` with `[sip]` on (`sip/mpbx.toml`) | default | **host** | SIP UDP+TCP `5060` on the host; HTTP on loopback; healthcheck `mpbx healthcheck` (`/readyz` on the metrics listener) |
| `mpbx-sip-engine` (Linux file) | `MPBX_IMAGE`, role `engine` (`sip/engine.toml`) | default | `data` | nothing; reaches NG and `mpbx-media` on `MPBX_BRIDGE_GATEWAY`; restarting it alone keeps the phones' connections on the edge |

Enable profiles with `COMPOSE_PROFILES=observability,turn` in `.env`. Grafana's ClickHouse datasource uses the
read-only user `mpbx_ro`, which can read the `mpbx` database only (no `system`, no writes).

Observability (W4-OBS-01, [guide](../../../docs/guides/observability.md)): `COMPOSE_PROFILES=observability` adds
Prometheus (scrapes `mpbx:9464`, shipped alert rules) and Grafana on `127.0.0.1:GRAFANA_PORT` (3000), login `admin` with
`GRAFANA_ADMIN_PASSWORD` from `.env`. Datasources (Prometheus, ClickHouse through the official plugin and the read-only user)
and eight dashboards (Overview, SIP, Trunks, Call Quality, Queues, Push, Infrastructure, CDR Explorer) are provisioned from
files: no manual setup. Reach it with an SSH tunnel or your reverse proxy; never open the port. The installer does this
with `--observability`.

TURN (`turn`, W4-MED-02): set `MPBX_ICE_STUN_URLS` and `MPBX_ICE_TURN_URLS` so the API hands out STUN and short-lived
per-device TURN credentials (from `TURN_SECRET`), and `MPBX_ICE_TURN_TLS_FORWARD` for TURN over TLS on the HTTPS port
(`host.docker.internal:3478` on Linux, `coturn:3478` on Docker Desktop). coturn refuses relaying to private, loopback,
link-local/metadata, CGNAT and special ranges (`coturn/turnserver.conf`, checked by `scripts/validate.sh`);
`TURN_ALLOWED_PEER_IP` admits one private media address when you need it. Guide:
[nat-turn.md](../../../docs/guides/nat-turn.md).

### Networking, and one deviation from the plan

* **Databases**: `data` is `internal: true` (no gateway, no route out) and nothing publishes a port. `scripts/validate.sh`
  (`make compose-prod-config`) fails if that ever changes.
* **rtpengine, coturn and the SIP edge use host networking on Linux** (`compose.linux.yaml`), which keeps client
  source IPs and avoids proxying a 10 000-port UDP range. rtpengine's NG protocol is unauthenticated, so it
  listens on `127.0.0.1` only. Open UDP `RTPE_PORT_MIN-RTPE_PORT_MAX` in the firewall; behind NAT set
  `RTPE_ADVERTISE=<public IP>`. `./start.sh` detects `RTPE_INTERFACE`.
* **rtpengine timeouts** (`rtpengine/start.sh`, the same file in Kubernetes): `--timeout=300` (rtpengine's default
  is 60) and `--silent-timeout=3600`, overridable with `RTPE_TIMEOUT` / `RTPE_SILENT_TIMEOUT`. rtpengine deletes a
  session that sees no RTP for `--timeout`, and it has no per-call setting; a caller queued at an emergency centre
  (183 with SDP, no RTP either way) would lose its media relay after 60 s. The B2BUA re-anchors such an emergency
  call anyway (`docs/guides/emergency.md`); the longer timeout makes that rare. It costs nothing: the PBX deletes
  every session when its call ends, and normal calls end at `ring_timeout` / `max_call_duration`.
* **`mpbx` itself stays on the bridge networks, SIP runs in `mpbx-sip` (FU-W4QA01-1).** A host-network container
  cannot reach databases that live on an internal network. The SIP edge, registrar and B2BUA need the real network
  stack (client source addresses for NAT handling and bans, 5060 on the host), so they run in the `mpbx-sip`
  service: the same image, role `all` with `[sip]` on, like the Kubernetes `mpbx-sip` pod, while `mpbx` is the API
  role. `mpbx-sip` reaches the databases on the host's **loopback** (`127.0.0.1:15432`, `16379`, `18124`,
  `MPBX_PG_LOOPBACK_PORT` and friends): postgres, valkey and clickhouse also join the bridge `dbhost`, which has no
  masquerading (still no route to the internet), only to publish those loopback ports. It reaches rtpengine NG
  (`127.0.0.1:22222`) and `mpbx-media` (`127.0.0.1:7090`) on the same loopback. Phones register against
  `MPBX_SIP_ADVERTISE` (default `RTPE_ADVERTISE`, else `RTPE_INTERFACE`; the installer sets the domain). Open UDP and
  TCP `5060`. `MPBX_SIP_DRAIN_SECS` makes `docker stop` wait for established calls (docs/guides/rolling-upgrade.md).
  Splitting a database-free `edge` role off, which would drop the loopback database ports, is FU-W10-PLAT-02-2.
* **Docker Desktop (macOS/Windows)** has no real host networking: `compose.desktop.yaml` keeps everything on the
  bridge and publishes a reduced RTP range on `127.0.0.1`. Dev and trial only; Windows is never a production host.

### `mpbx-media` is behind a profile

Its image is still a stub that prints its version and exits (FU-DEP01-L1 in
[security follow-ups](../../../docs/security/followups.md)), so enabling it by default would make `up --wait` fail.
Turn the profile on (`COMPOSE_PROFILES=media`) when the binary runs as a service.

## Sizing the RTP range

rtpengine uses **4 UDP ports per relayed call**, so `RTPE_PORT_MIN-RTPE_PORT_MAX` carries `(max - min + 1) / 4` calls:
the default 30000-40000 is 2,500, less than 4 vCPUs of userspace forwarding carry (about 3,000; FU-W5QA04-3,
docs/guides/load-and-sizing.md). At exhaustion rtpengine rejects the `offer` and calls fail. Set the maximum for your
planned peak, keep it below `TURN_MIN_PORT` (49160) and open the same range in the firewall. The VM installer does it
with `--calls N`; `rtpengine/start.sh` logs the capacity of the range at every start, and `mpbx sizing` warns when it
is too small. Several media nodes behind 1:1 NAT: `RTPE_ADVERTISE_MAP` (FU-DEP03-L2) gives each node its own public
address, `10.0.0.5=203.0.113.5,10.0.0.6=203.0.113.6`.

## Secrets and database roles

* There are **no default secrets**. Every password and key is `${VAR:?...}`: `docker compose` refuses to start until
  `mpbx init` has written them (checked by `scripts/validate.sh`).
* Valkey and coturn read their password from a config file in tmpfs, written at start; Postgres, ClickHouse and
  Grafana read the environment. No secret is on any process command line (W0 #6 L1).
* **Postgres** (FU-PBX10-M1b): the image's `POSTGRES_USER` is a superuser and bypasses row-level security. The init
  script `postgres/initdb/10-mpbx-roles.sh` runs on the first start only and creates the application login `mpbx`
  (LOGIN, CREATEROLE for the migrations, NOSUPERUSER, NOBYPASSRLS, NOREPLICATION) as the owner of the `mpbx`
  database, then **removes the password of the superuser `mpbx_admin`**. The superuser is reachable only over the
  container's local socket: `docker compose exec postgres psql -U mpbx_admin -d mpbx`. Row-level security is
  FORCEd on tenant tables, so even the owner sees only its transaction's company. Splitting the one application
  login into tenant, system and migration logins (rest of FU-PBX10-M1) is still open.
* **ClickHouse** read-only user: `GRANT SELECT ON mpbx.*` only (W0 #6 L2).
* Every container drops all capabilities and sets `no-new-privileges`; `mpbx`, `rtpengine`, `valkey`, `prometheus` and
  `coturn` also have a read-only root file system. `mpbx` runs as 65532, `rtpengine` as `rtpengine` (W0 #6 L3).

## Operations

```sh
./start.sh                       # idempotent: init is skipped once the secrets exist
./start.sh ps | logs -f mpbx     # any docker compose command
./start.sh down                  # stop, keep data
docker compose -f compose.yaml -f compose.linux.yaml down -v   # DELETES the databases (and nothing else)
```

Set `COMPOSE_PROJECT_NAME` to run a second copy next to this one (default project `mpbx-prod`; the dev sandbox is
`mpbx`). Upgrade and rollback: `deploy/installer/bin/mpbx-ctl upgrade|rollback` with `MPBX_ROOT` pointing at the
directory that holds `compose/prod` (docs/guides/upgrade-rollback.md, W4-DEP-05); ACME/HTTPS for the web port and the installer (Docker
install, DNS and port preflight) are W4-DEP-04 and W4-SEC-01 (`MPBX__TLS__*`).

## Backup and restore (W4-DEP-06)

Backups are passphrase-encrypted, include the master key, and go to `./backups` (`MPBX_BACKUP_DIR`), S3 or GCS. The
one-off service `mpbx-ops` (profile `ops`, never started by `up`) runs `mpbx backup` / `mpbx restore` with the
application's own environment and database login. `--user` keeps the files yours.

```sh
umask 077; openssl rand -base64 24 > backup.pass       # keep a copy OFF this host: without it a backup is useless
docker compose run --rm --user "$(id -u):$(id -g)" -v "$PWD/backup.pass:/run/backup.pass:ro" \
    mpbx-ops backup --passphrase-file /run/backup.pass --prune          # or schedule it in the console
docker compose run --rm --user "$(id -u):$(id -g)" -v "$PWD/backup.pass:/run/backup.pass:ro" \
    mpbx-ops backup verify latest --passphrase-file /run/backup.pass    # every chunk decrypted
```

Restore onto a fresh host: `init`, start only `postgres valkey clickhouse`, then
`mpbx-ops restore latest --passphrase-file ... --sink env-file:/work/.env` (with `-v "$PWD:/work"`), then
`up -d --wait`. Full procedure: [runbook](../../../docs/runbooks/restore-on-a-new-host.md), reference:
[guide](../../../docs/guides/backup-restore.md). `scripts/restore-test.sh` runs the whole cycle on two throw-away
projects (`MPBX_IMAGE=... scripts/restore-test.sh`).

## Files

| File | Purpose |
|---|---|
| `compose.init.yaml` | one-shot `mpbx init` (no secrets needed to load it) |
| `compose.yaml` | the bundle |
| `compose.linux.yaml` | host networking for rtpengine, coturn, the edge |
| `compose.desktop.yaml` | Docker Desktop fallback, dev and trial only |
| `.env.example` | settings (no secrets); `.env` is created from it and filled by `mpbx init` |
| `start.sh` | create `.env`, init once, detect the interface, `up -d --wait` |
| `scripts/validate.sh` | static invariants, starts nothing (`make compose-prod-config`) |
| `scripts/smoke.sh` | runtime checks against a started project |
| `scripts/restore-test.sh` | backup -> fresh host -> restore on two throw-away projects (W4-DEP-06) |
| `postgres/`, `clickhouse/`, `coturn/`, `rtpengine/`, `prometheus/` | mounted configuration |

Grafana provisioning (datasources and the dashboard JSON) and the alert rules are shared with the dev sandbox (`../grafana`,
`../prometheus/rules`); `make grafana-check` lints the dashboards, `scripts/validate.sh` checks the profile.
