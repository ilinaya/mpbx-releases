#!/usr/bin/env python3
"""Offline checks of grafana-company-user.py (FU-OBS01-L3): run with python3 -I (needs no ClickHouse)."""
import importlib.util
import re
import subprocess
import sys
import base64
import json
import os
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
import xml.etree.ElementTree as ET
from pathlib import Path

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("gcu", HERE / "grafana-company-user.py")
gcu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gcu)
A = "11111111-1111-1111-1111-111111111111"
B = "22222222-2222-2222-2222-222222222222"


class T(unittest.TestCase):
    def test_every_tenant_table_is_found(self):
        t = gcu.tenant_tables(gcu.DEFAULT_MIGRATIONS)
        for need in ["cdr_calls", "cdr_legs", "call_quality", "call_events", "audit_log", "app_logs", "queue_events", "webhook_attempts"]:
            self.assertIn(need, t)

    def test_every_create_table_has_tenant_id(self):
        # a table without tenant_id would be invisible to company users silently: make it a loud failure here
        all_tables = []
        for f in sorted(gcu.DEFAULT_MIGRATIONS.glob("*.sql")):
            all_tables += re.findall(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", re.sub(r"--[^\n]*", "", f.read_text()), re.I)
        self.assertEqual(sorted(set(all_tables)), sorted(gcu.tenant_tables(gcu.DEFAULT_MIGRATIONS)))

    def test_render_filters_each_table_to_its_company(self):
        tables = ["cdr_calls", "audit_log"]
        xml = gcu.render({"acme": (A, "a" * 64), "beta": (B, "b" * 64)}, tables)
        root = ET.fromstring(xml)
        for slug, cid in (("acme", A), ("beta", B)):
            u = root.find(f"users/mpbx_ro_{slug}")
            self.assertIsNotNone(u)
            self.assertEqual(u.findtext("profile"), "mpbx_readonly")
            self.assertEqual([g.text for g in u.findall("grants/query")], [f"GRANT SELECT ON mpbx.{t}" for t in tables])
            for t in tables:
                self.assertEqual(u.findtext(f"databases/mpbx/{t}/filter"), f"tenant_id = toUUID('{cid}')")
        self.assertNotIn(B, xml.split("mpbx_ro_beta")[0])  # company B's id never appears in A's block

    def test_no_password_in_clear_and_no_blanket_grant(self):
        xml = gcu.render({"acme": (A, "a" * 64)}, ["cdr_calls"])
        self.assertNotIn("<password>", xml)
        self.assertNotIn("mpbx.*", xml)

    def test_add_remove_roundtrip_and_nil_refused(self):
        with tempfile.TemporaryDirectory() as d:
            f = str(Path(d) / "c.xml")
            run = lambda *a: subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "--file", f, *a], capture_output=True, text=True)
            self.assertEqual(run("add", "acme", A).returncode, 0)
            self.assertEqual(run("add", "acme", B).returncode, 2)  # exists
            self.assertEqual(run("add", "nil", "00000000-0000-0000-0000-000000000000").returncode, 2)
            self.assertEqual(run("add", "Bad Slug", A).returncode, 2)
            out = run("list")
            self.assertIn(f"mpbx_ro_acme\t{A}", out.stdout)
            self.assertEqual(run("remove", "acme").returncode, 0)
            self.assertEqual(Path(f).read_text(), gcu.EMPTY)

    def test_k8s_file_is_the_default_with_k8s_flag_and_ships_empty(self):
        # FU-OBS01-L3b: the Kubernetes base mounts this file; it ships with no users
        self.assertEqual(gcu.K8S_FILE.read_text(), gcu.EMPTY)
        self.assertEqual(gcu.K8S_FILE.relative_to(gcu.ROOT).as_posix(), "deploy/k8s/base/files/clickhouse-company-users.xml")
        kust = (gcu.ROOT / "deploy/k8s/base/kustomization.yaml").read_text()
        sts = (gcu.ROOT / "deploy/k8s/base/clickhouse.yaml").read_text()
        self.assertIn("files/clickhouse-company-users.xml", kust)
        self.assertIn("subPath: clickhouse-company-users.xml", sts)
        with tempfile.TemporaryDirectory() as d:
            f = str(Path(d) / "k.xml")
            run = lambda *a: subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "--k8s", "--file", f, *a], capture_output=True, text=True)
            r = run("add", "acme", A)
            self.assertEqual(r.returncode, 0)
            self.assertIn("kubectl apply -k", r.stderr)
            self.assertIn(f"mpbx_ro_acme\t{A}", run("list").stdout)


class FakeGrafana(BaseHTTPRequestHandler):
    orgs: dict = {}
    sources: list = []
    seen: list = []
    users: dict = {}
    members: set = set()

    def log_message(self, *a):
        pass

    def _send(self, code, body=None):
        raw = json.dumps(body).encode() if body is not None else b""
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth_ok(self):
        return self.headers.get("Authorization") == "Basic " + base64.b64encode(b"admin:grafana-pw").decode()

    def do_GET(self):
        if not self._auth_ok():
            return self._send(401, {"message": "no"})
        if self.path.startswith("/api/orgs/name/"):
            name = self.path.rsplit("/", 1)[1]
            return self._send(200, {"id": self.orgs[name], "name": name}) if name in self.orgs else self._send(404, {"message": "not found"})
        if self.path.startswith("/api/users/lookup?loginOrEmail="):
            who = self.path.split("=", 1)[1].replace("%40", "@")
            return self._send(200, {"login": who}) if who in self.users else self._send(404, {"message": "not found"})
        self._send(404)

    def do_POST(self):
        if not self._auth_ok():
            return self._send(401, {"message": "no"})
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        FakeGrafana.seen.append((self.path, self.headers.get("X-Grafana-Org-Id"), body))
        if self.path == "/api/orgs":
            self.orgs[body["name"]] = 7
            return self._send(200, {"orgId": 7})
        if self.path == "/api/datasources":
            org = self.headers.get("X-Grafana-Org-Id")
            if any(s == (org, body["name"]) for s in self.sources):
                return self._send(409, {"message": "exists"})
            self.sources.append((org, body["name"]))
            return self._send(200, {"id": 1})
        if self.path == "/api/admin/users":
            self.users[body["login"]] = body["password"]
            return self._send(200, {"id": 2})
        if self.path.startswith("/api/orgs/") and self.path.endswith("/users"):
            key = (self.path.split("/")[3], body["loginOrEmail"], body["role"])
            if key in self.members:
                return self._send(409, {"message": "exists"})
            self.members.add(key)
            return self._send(200, {"message": "ok"})
        self._send(404)


class GrafanaSetup(unittest.TestCase):
    def test_org_and_datasource_are_created_once_and_use_the_company_user(self):
        FakeGrafana.orgs, FakeGrafana.sources, FakeGrafana.seen = {}, [], []
        srv = HTTPServer(("127.0.0.1", 0), FakeGrafana)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{srv.server_port}"
        try:
            first = gcu.grafana_setup(url, "acme", "company-ch-pw", "grafana-pw", "clickhouse")
            self.assertIn("organisation company-acme created (id 7)", first)
            self.assertIn("datasource ClickHouse created in company-acme for user mpbx_ro_acme", first)
            path, org, ds = FakeGrafana.seen[-1]
            self.assertEqual((path, org), ("/api/datasources", "7"))  # in the company's organisation
            self.assertEqual(ds["jsonData"]["username"], "mpbx_ro_acme")
            self.assertEqual(ds["jsonData"]["host"], "clickhouse")
            self.assertEqual(ds["secureJsonData"]["password"], "company-ch-pw")
            second = gcu.grafana_setup(url, "acme", "company-ch-pw", "grafana-pw", "clickhouse")
            self.assertIn("organisation company-acme exists (id 7)", second)
            self.assertIn("datasource ClickHouse already exists in company-acme; left unchanged", second)
            with self.assertRaises(RuntimeError):
                gcu.grafana_setup(url, "acme", "company-ch-pw", "wrong", "clickhouse")
        finally:
            srv.shutdown()

    def test_cli_grafana_needs_the_passwords_and_a_known_user(self):
        with tempfile.TemporaryDirectory() as d:
            f = str(Path(d) / "c.xml")
            env = {k: v for k, v in os.environ.items() if k not in ("GRAFANA_ADMIN_PASSWORD", "COMPANY_CH_PASSWORD")}
            run = lambda *a: subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "--file", f, *a], capture_output=True, text=True, env=env)
            self.assertEqual(run("grafana", "acme", "--url", "http://127.0.0.1:1").returncode, 2)  # unknown user
            self.assertEqual(run("add", "acme", A).returncode, 0)
            self.assertEqual(run("grafana", "acme", "--url", "http://127.0.0.1:1").returncode, 2)  # no passwords

    def test_staff_logins_are_created_once_and_added_as_viewers(self):
        FakeGrafana.orgs, FakeGrafana.sources, FakeGrafana.seen = {}, [], []
        FakeGrafana.users, FakeGrafana.members = {"old@acme.example": "x"}, set()
        srv = HTTPServer(("127.0.0.1", 0), FakeGrafana)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{srv.server_port}"
        try:
            with self.assertRaises(RuntimeError):  # no organisation yet
                gcu.grafana_staff(url, "acme", ["a@acme.example"], "grafana-pw")
            gcu.grafana_setup(url, "acme", "company-ch-pw", "grafana-pw", "clickhouse")
            first = gcu.grafana_staff(url, "acme", ["new@acme.example", "old@acme.example"], "grafana-pw")
            self.assertTrue(any(l.startswith("login new@acme.example created; password") for l in first))
            self.assertIn("login old@acme.example exists", first)
            self.assertEqual(FakeGrafana.members, {("7", "new@acme.example", "Viewer"), ("7", "old@acme.example", "Viewer")})
            self.assertEqual(len(FakeGrafana.users["new@acme.example"]), 24)  # random, not derived from the address
            second = gcu.grafana_staff(url, "acme", ["new@acme.example"], "grafana-pw")
            self.assertEqual(second, ["login new@acme.example exists", "new@acme.example is already in company-acme; left unchanged"])
            with self.assertRaises(RuntimeError):
                gcu.grafana_staff(url, "acme", ["new@acme.example"], "wrong")
        finally:
            srv.shutdown()

    def test_leavers_are_removed_from_the_organisation_only(self):
        # FU-OBS01-L3d: --remove-leavers drops org membership of members not on the staff list, keeps logins and admin.
        calls = []
        members = [
            {"userId": 1, "login": "admin", "email": "admin@x.example", "role": "Admin"},
            {"userId": 2, "login": "kept@acme.example", "email": "kept@acme.example", "role": "Viewer"},
            {"userId": 3, "login": "gone@acme.example", "email": "gone@acme.example", "role": "Viewer"},
            {"userId": 4, "login": "Staff", "email": "Staff@Acme.example", "role": "Editor"},
        ]

        def fake(url, method, path, auth, body=None, org=None):
            calls.append((method, path))
            if method == "GET" and path == "/api/orgs/name/company-acme":
                return 200, {"id": 7, "name": "company-acme"}
            if method == "GET" and path == "/api/orgs/7/users":
                return 200, members
            if method == "DELETE":
                return 200, {"message": "removed"}
            return 200, {}

        orig = gcu.grafana_call
        gcu.grafana_call = fake
        try:
            lines = gcu.grafana_staff("http://g", "acme", ["kept@acme.example", "staff@acme.example"], "grafana-pw",
                                      remove_leavers=True)
            self.assertEqual([c for c in calls if c[0] == "DELETE"], [("DELETE", "/api/orgs/7/users/3")])
            self.assertTrue(any("gone@acme.example is not on the staff list" in l for l in lines))
            calls.clear()
            gcu.grafana_staff("http://g", "acme", ["kept@acme.example"], "grafana-pw")
            self.assertFalse(any(c[0] == "DELETE" for c in calls))  # off by default
        finally:
            gcu.grafana_call = orig

    def test_cli_staff_accepts_remove_leavers(self):
        ap_help = subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "staff", "--help"], capture_output=True, text=True)
        self.assertIn("--remove-leavers", ap_help.stdout)

    def test_parse_emails(self):
        self.assertEqual(gcu.parse_emails("A@x.example, b@x.example;a@x.example\n# note\nc@x.example # trailing\n"),
                         ["a@x.example", "b@x.example", "c@x.example"])
        with self.assertRaises(ValueError):
            gcu.parse_emails("not-an-address")

    def test_cli_staff_needs_a_known_user_password_and_list(self):
        with tempfile.TemporaryDirectory() as d:
            f, lst = str(Path(d) / "c.xml"), Path(d) / "emails.txt"
            env = {k: v for k, v in os.environ.items() if k != "GRAFANA_ADMIN_PASSWORD"}
            run = lambda *a, e=env: subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "--file", f, *a], capture_output=True, text=True, env=e)
            args = ("staff", "acme", "--url", "http://127.0.0.1:1", "--emails", str(lst))
            self.assertEqual(run(*args).returncode, 2)  # unknown user
            self.assertEqual(run("add", "acme", A).returncode, 0)
            self.assertEqual(run(*args).returncode, 2)  # no admin password
            lst.write_text("# nobody\n")
            self.assertEqual(run(*args, e={**env, "GRAFANA_ADMIN_PASSWORD": "p"}).returncode, 2)  # empty list
            lst.write_text("bad address\n")
            self.assertEqual(run(*args, e={**env, "GRAFANA_ADMIN_PASSWORD": "p"}).returncode, 2)  # bad address

    def test_sandbox_file_ships_empty_is_mounted_and_is_the_sandbox_default(self):
        root = HERE.parents[3]
        shipped = root / "deploy/compose/clickhouse/users.d/company-users.xml"
        self.assertEqual(ET.parse(shipped).getroot().tag, "clickhouse")
        self.assertEqual(len(ET.parse(shipped).getroot()), 0)
        self.assertEqual(gcu.SANDBOX_FILE, shipped)
        self.assertIn("./clickhouse/users.d/company-users.xml:/etc/clickhouse-server/users.d/company-users.xml:ro",
                      (root / "deploy/compose/compose.yaml").read_text())
        with tempfile.TemporaryDirectory() as d:
            f = str(Path(d) / "c.xml")  # --sandbox picks SANDBOX_FILE; here only the flag's hint is checked via --file override
            r = subprocess.run([sys.executable, "-I", str(HERE / "grafana-company-user.py"), "--file", f, "--sandbox", "add", "acme", A],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("restart the sandbox ClickHouse", r.stderr)


if __name__ == "__main__":
    unittest.main()
