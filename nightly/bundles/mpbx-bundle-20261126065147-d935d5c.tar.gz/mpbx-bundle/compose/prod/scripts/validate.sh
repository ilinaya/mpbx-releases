#!/usr/bin/env bash
# Static check of the production bundle (W4-DEP-02): no containers are started, no secrets are needed.
#
#   deploy/compose/prod/scripts/validate.sh       (or: make compose-prod-config)
#
# It renders every file combination and profile with placeholder values (never used for anything) and asserts the
# guarantees of compose.yaml: the databases publish nothing and sit on an internal network only; nothing has a
# default secret (rendering fails without the secrets); Linux uses host networking for rtpengine, coturn and the
# edge; every third-party image is pinned by digest; Docker Desktop publishes only loopback addresses.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

# Placeholders only to make the files render; they are not secrets and nothing connects with them.
placeholders=(
  MPBX_IMAGE=example/mpbx:test MPBX_RTPENGINE_IMAGE=example/mpbx-rtpengine:test MPBX_MEDIA_IMAGE=example/mpbx-media:test
  POSTGRES_PASSWORD=PLACEHOLDER-SECRET VALKEY_PASSWORD=PLACEHOLDER-SECRET CLICKHOUSE_PASSWORD=PLACEHOLDER-SECRET
  POSTGRES_TENANT_PASSWORD=PLACEHOLDER-SECRET POSTGRES_SYSTEM_PASSWORD=PLACEHOLDER-SECRET
  POSTGRES_RESTORE_PASSWORD=PLACEHOLDER-SECRET POSTGRES_APP_PASSWORD=PLACEHOLDER-SECRET
  CLICKHOUSE_RO_PASSWORD=PLACEHOLDER-SECRET GRAFANA_ADMIN_PASSWORD=PLACEHOLDER-SECRET TURN_SECRET=PLACEHOLDER-SECRET
  MPBX_JWT_SIGNING_KEY=x MPBX_JWT_PUBLIC_KEY=x MPBX_JWT_KID=x MPBX_MASTER_KEY=x MPBX_MASTER_KEY_ID=x
  MPBX_RELAY_INSTANCE_KEY=x MPBX_RELAY_INSTANCE_PUBLIC_KEY=x MPBX_PROVISIONING_SECRET=x RTPE_INTERFACE=10.0.0.5
  MPBX_MEDIA_CONTROL_SECRET=PLACEHOLDER-SECRET
)
# `.env` of a real install must not leak into the check.
render() { env -i PATH="$PATH" HOME="${HOME:-/}" "${placeholders[@]}" docker compose --env-file /dev/null "$@" config --format json; }

fail=0
ok()  { printf '  ok    %s\n' "$*"; }
bad() { printf '  FAIL  %s\n' "$*"; fail=1; }

echo "== no defaults: rendering must fail without the secrets"
if env -i PATH="$PATH" HOME="${HOME:-/}" MPBX_IMAGE=a MPBX_RTPENGINE_IMAGE=b MPBX_MEDIA_IMAGE=c docker compose --env-file /dev/null -f compose.yaml config >/dev/null 2>&1; then
  bad "compose.yaml renders without POSTGRES_PASSWORD and the other secrets"
else
  ok "compose.yaml refuses to render without the secrets from mpbx init"
fi

echo "== fresh install: only the variables README and .env.example require (no profiles)"
# A service of an inactive profile is still interpolated, so a required-variable check on it would break a plain
# `docker compose up`. Render with just the three images plus the secrets mpbx init writes. MVP-GAP-02: mpbx-media is
# a default service now, so its image and the media control secret are required (a fresh install has both).
fresh=(MPBX_IMAGE=a MPBX_RTPENGINE_IMAGE=b
  POSTGRES_PASSWORD=P POSTGRES_TENANT_PASSWORD=P POSTGRES_SYSTEM_PASSWORD=P POSTGRES_RESTORE_PASSWORD=P POSTGRES_APP_PASSWORD=P
  VALKEY_PASSWORD=P CLICKHOUSE_PASSWORD=P CLICKHOUSE_RO_PASSWORD=P GRAFANA_ADMIN_PASSWORD=P TURN_SECRET=P
  MPBX_JWT_SIGNING_KEY=x MPBX_JWT_PUBLIC_KEY=x MPBX_JWT_KID=x MPBX_MASTER_KEY=x MPBX_MASTER_KEY_ID=x
  MPBX_RELAY_INSTANCE_KEY=x MPBX_RELAY_INSTANCE_PUBLIC_KEY=x MPBX_PROVISIONING_SECRET=x RTPE_INTERFACE=10.0.0.5)
for combo in "compose.yaml compose.linux.yaml" "compose.yaml compose.desktop.yaml"; do
  files=(); for f in $combo; do files+=(-f "$f"); done
  if env -i PATH="$PATH" HOME="${HOME:-/}" "${fresh[@]}" MPBX_MEDIA_IMAGE=c MPBX_MEDIA_CONTROL_SECRET=P \
      docker compose --env-file /dev/null "${files[@]}" config >/dev/null 2>&1; then
    ok "$combo renders with the three images plus the init secrets"
  else
    bad "$combo needs more than MPBX_IMAGE, MPBX_RTPENGINE_IMAGE, MPBX_MEDIA_IMAGE (plus init secrets) on a fresh install"
  fi
  for missing in MPBX_MEDIA_IMAGE MPBX_MEDIA_CONTROL_SECRET; do
    extra=(MPBX_MEDIA_IMAGE=c MPBX_MEDIA_CONTROL_SECRET=P)
    kept=(); for e in "${extra[@]}"; do [ "${e%%=*}" = "$missing" ] || kept+=("$e"); done
    if env -i PATH="$PATH" HOME="${HOME:-/}" "${fresh[@]}" "${kept[@]}" \
        docker compose --env-file /dev/null "${files[@]}" config >/dev/null 2>&1; then
      bad "$combo renders without $missing (mpbx-media would start without it)"
    else
      ok "$combo refuses to render without $missing"
    fi
  done
done

echo "== compose.init.yaml"
env -i PATH="$PATH" HOME="${HOME:-/}" MPBX_IMAGE=a docker compose --env-file /dev/null -f compose.init.yaml config >/dev/null \
  && ok "renders with only MPBX_IMAGE (needs no secret)" || bad "compose.init.yaml needs more than MPBX_IMAGE"

for combo in "compose.yaml compose.linux.yaml" "compose.yaml compose.desktop.yaml"; do
  files=(); for f in $combo; do files+=(-f "$f"); done
  echo "== $combo (all profiles)"
  json="$(render "${files[@]}" --profile observability --profile turn)" \
    || { bad "does not render"; continue; }
  python3 - "$combo" "$json" <<'PY' && ok "invariants hold" || bad "invariant violated"
import json, re, sys
combo, cfg = sys.argv[1], json.loads(sys.argv[2])
svc, nets = cfg["services"], cfg["networks"]
err = []
if not nets["data"].get("internal"): err.append("network data is not internal")
linux = combo.endswith("compose.linux.yaml")
PRIVATE = r"^(127\.0\.0\.1|172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+)"
for name in ("postgres", "valkey", "clickhouse", "prometheus"):
    s = svc[name]
    if linux and name == "valkey":
        # FU-GAPB28-2: only Valkey publishes, on the host's loopback, for the database-free SIP edge (host network);
        # the extra network it joins has no masquerading (no route to the internet).
        if not s.get("ports"): err.append("valkey publishes no loopback port for the SIP edge")
        for p in s.get("ports", []):
            if p.get("host_ip") != "127.0.0.1": err.append(f"{name} publishes {p.get('published')} on {p.get('host_ip') or 'all addresses'}")
        if set(s.get("networks", {})) != {"data", "dbhost"}: err.append(f"{name} must be on data and dbhost only")
        if nets.get("dbhost", {}).get("driver_opts", {}).get("com.docker.network.bridge.enable_ip_masquerade") != "false": err.append("network dbhost must not masquerade")
        if nets.get("dbhost", {}).get("internal"): err.append("network dbhost cannot be internal (it exists to publish loopback ports)")
        continue
    if s.get("ports"): err.append(f"{name} publishes ports")
    # Prometheus is also on `edge` (FU-GAP02-4: it scrapes mpbx-media there / on the host); it publishes nothing.
    if set(s.get("networks", {})) - ({"data", "edge"} if name == "prometheus" else {"data"}): err.append(f"{name} is on a network other than data")
for name, s in svc.items():
    for p in s.get("ports", []):
        if p.get("host_ip") not in ("127.0.0.1",) and name != "mpbx":
            err.append(f"{name} publishes {p.get('published')} on {p.get('host_ip') or 'all addresses'}")
    img = s.get("image", "")
    if name in ("postgres", "valkey", "clickhouse", "coturn", "prometheus", "grafana") and "@sha256:" not in img:
        err.append(f"{name} image {img} is not pinned by digest")
    if "cap_drop" not in s or "ALL" not in s["cap_drop"]:
        err.append(f"{name} does not drop capabilities")
    env = s.get("environment", {})
    for k, v in env.items():
        if re.search(r"PASSWORD|SECRET|KEY", k) and v in ("", None) and k not in ("MPBX_JWT_PREVIOUS_KEYS", "MPBX_MEDIA_STREAM_TICKET_KEY"):  # optional by design (previous keys; stream ticket key FU-W9-AI-06-5c)
            err.append(f"{name}: {k} is empty")
    cmd = " ".join(str(c) for c in (s.get("command") or []) + (s.get("entrypoint") or []))
    if "PLACEHOLDER-SECRET" in cmd:
        err.append(f"{name}: a secret is on the command line")
# FU-DEP06-M1f: every mpbx server process runs on the non-owner application login; the owner login is only the
# start-up / CLI one (MPBX__POSTGRES__OWNER_URL).
for name in ("mpbx", "mpbx-sip-engine", "mpbx-ops"):
    e = (svc.get(name) or {}).get("environment") or {}
    if name not in svc: continue
    if not str(e.get("MPBX__POSTGRES__URL", "")).startswith("postgres://mpbx_app_login:"): err.append(f"{name}: MPBX__POSTGRES__URL is not the application login mpbx_app_login")
    if not str(e.get("MPBX__POSTGRES__OWNER_URL", "")).startswith("postgres://mpbx:"): err.append(f"{name}: MPBX__POSTGRES__OWNER_URL is not the owner login mpbx")
    for k in ("MPBX__POSTGRES__TENANT_URL", "MPBX__POSTGRES__SYSTEM_URL"):
        if not e.get(k): err.append(f"{name}: {k} is missing (mpbx_app_login needs the scope logins)")
# MVP-GAP-02: mpbx-media is a default service, never on the database network, never publishing its control port.
m = svc.get("mpbx-media")
if m is None: err.append("mpbx-media is not a default service")
else:
    if m.get("profiles"): err.append("mpbx-media is behind a profile")
    if m.get("ports"): err.append("mpbx-media publishes ports (the control port must stay internal)")
    if "data" in (m.get("networks") or {}): err.append("mpbx-media is on the database network")
    menv = m.get("environment", {})
    if not menv.get("MPBX_MEDIA_CONTROL_SECRET"): err.append("mpbx-media has no control secret")
    if not any(v.get("target") == "/var/lib/mpbx/files" for v in m.get("volumes", [])): err.append("mpbx-media has no file store")
    if svc["mpbx"]["environment"].get("MPBX__MEDIA__MODE") != "remote": err.append("the engine is not in remote media mode")
    if combo.endswith("compose.linux.yaml"):
        if m.get("network_mode") != "host": err.append("mpbx-media is not beside rtpengine on the host network")
        if not str(menv.get("MPBX__MEDIA__BIND_HOST", "")).startswith("127.0.0.1"): err.append("mpbx-media MPBX__MEDIA__BIND_HOST is not loopback on the host network")
        # FU-GAPB28-2: the control port on the Docker bridge gateway (private) for the engine, never 0.0.0.0.
        if not re.match(PRIVATE + r":7090$", str(menv.get("MPBX__MEDIA__LISTEN", ""))): err.append("mpbx-media MPBX__MEDIA__LISTEN is not loopback or a private bridge address")
        # FU-GAP02-4: metrics only on the Docker bridge gateway (private: containers and the host), never 0.0.0.0.
        if not re.match(r"^(127\.0\.0\.1|172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+):19465$", str(menv.get("MPBX__METRICS__LISTEN", ""))): err.append("mpbx-media MPBX__METRICS__LISTEN is not loopback or a private bridge address")
        if svc["mpbx-sip-engine"]["environment"].get("MPBX__MEDIA__REMOTE") != menv.get("MPBX__MEDIA__LISTEN"): err.append("mpbx-sip-engine does not use mpbx-media's control address")
if combo.endswith("compose.linux.yaml"):
    # FU-W4QA01-1: the SIP service is a default service on the host network, beside rtpengine; only HTTP/metrics
    # on loopback, databases on the loopback ports, SIP enabled from the mounted file, nothing published by Docker.
    sip = svc.get("mpbx-sip")
    if sip is None: err.append("mpbx-sip (the SIP service) is missing")
    else:
        if sip.get("profiles"): err.append("mpbx-sip is behind a profile")
        if sip.get("ports"): err.append("mpbx-sip publishes ports (it binds the host network itself)")
        se = sip.get("environment", {})
        if not str(se.get("MPBX__HTTP__LISTEN", "")).startswith("127.0.0.1:"): err.append("mpbx-sip MPBX__HTTP__LISTEN is not loopback")
        # FU-OBS01-L2: metrics only on the Docker bridge gateway (private), scraped by Prometheus; never 0.0.0.0.
        if not re.match(r"^(127\.0\.0\.1|172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+):19464$", str(se.get("MPBX__METRICS__LISTEN", ""))): err.append("mpbx-sip MPBX__METRICS__LISTEN is not loopback or a private bridge address")
        # FU-GAPB28-2: the edge role opens no database: only Valkey (the bus), on its loopback port.
        if "@127.0.0.1:" not in str(se.get("MPBX__VALKEY__URL", "")): err.append("mpbx-sip MPBX__VALKEY__URL does not use the loopback port")
        for k in ("MPBX__POSTGRES__URL", "MPBX__POSTGRES__TENANT_URL", "MPBX__POSTGRES__SYSTEM_URL", "MPBX__CLICKHOUSE__URL"):
            if se.get(k): err.append(f"mpbx-sip (the edge) has {k}: it must stay database-free")
        if set(sip.get("depends_on", {})) - {"valkey"}: err.append("mpbx-sip depends on more than valkey")
        # FU-GAPB28-2a: the edge has a healthcheck (`mpbx healthcheck` probes /readyz on the metrics listener).
        if (sip.get("healthcheck") or {}).get("test", [None, None])[1:2] != ["/usr/local/bin/mpbx"]: err.append("mpbx-sip has no mpbx healthcheck")
        if se.get("MPBX__NODE__ROLE") != "edge": err.append("mpbx-sip is not role edge")
        if not se.get("MPBX__SIP__ADVERTISE"): err.append("mpbx-sip has no sip.advertise")
        if not any(v.get("target") == "/etc/mpbx/mpbx.toml" for v in sip.get("volumes", [])): err.append("mpbx-sip has no [sip] config file")
    eng = svc.get("mpbx-sip-engine")
    if eng is None: err.append("mpbx-sip-engine (the SIP engine) is missing")
    else:
        ee = eng.get("environment", {})
        if eng.get("profiles"): err.append("mpbx-sip-engine is behind a profile")
        if eng.get("network_mode") == "host": err.append("mpbx-sip-engine must stay on the bridge (databases are internal)")
        if "data" not in (eng.get("networks") or {}): err.append("mpbx-sip-engine is not on the data network")
        if eng.get("ports"): err.append("mpbx-sip-engine publishes ports")
        if ee.get("MPBX__NODE__ROLE") != "engine": err.append("mpbx-sip-engine is not role engine")
        if "@postgres:5432" not in str(ee.get("MPBX__POSTGRES__URL", "")): err.append("mpbx-sip-engine does not reach postgres on the data network")
        if not any(v.get("source", "").endswith("sip/engine.toml") and v.get("target") == "/etc/mpbx/mpbx.toml" for v in eng.get("volumes", [])): err.append("mpbx-sip-engine has no sip/engine.toml")
    if svc["mpbx"]["environment"].get("MPBX__NODE__ROLE") != "api": err.append("mpbx is not the API role on Linux (the engine runs in mpbx-sip-engine)")
    toml = open("sip/mpbx.toml").read()
    for needle in ('enabled = true', 'listen_udp = ["0.0.0.0:5060"]', 'listen_tcp = ["0.0.0.0:5060"]', 'address = "127.0.0.1:22222"'):
        if needle not in toml: err.append(f"sip/mpbx.toml lacks {needle}")
    etoml = open("sip/engine.toml").read()
    ng = re.search(r'address = "([0-9.]+):22222"', etoml)
    if not ng or ng.group(1) != svc["rtpengine"]["environment"].get("RTPE_NG_LISTEN"): err.append("sip/engine.toml does not use rtpengine's NG address")
    for name in ("rtpengine", "coturn", "mpbx-sip"):
        if svc[name].get("network_mode") != "host": err.append(f"{name} is not on the host network on Linux")
    if svc["mpbx"].get("network_mode") == "host": err.append("mpbx must stay on the bridge (databases are internal)")
    # FU-GAPB28-2: NG (unauthenticated) on loopback or the Docker bridge gateway (private), never 0.0.0.0.
    if not re.match(PRIVATE + "$", str(svc["rtpengine"]["environment"].get("RTPE_NG_LISTEN"))): err.append("NG is not bound to loopback or a private bridge address")
    # The documented ports never change silently (MED-NAT-005, docs/guides/nat-turn.md).
    rtp = (svc["rtpengine"]["environment"].get("RTPE_PORT_MIN"), svc["rtpengine"]["environment"].get("RTPE_PORT_MAX"))
    if rtp != ("30000", "40000"): err.append(f"RTP range default is {rtp}, not the documented 30000-40000")
    turn = (svc["coturn"]["environment"].get("TURN_MIN_PORT"), svc["coturn"]["environment"].get("TURN_MAX_PORT"))
    if turn != ("49160", "49200"): err.append(f"TURN relay range default is {turn}, not the documented 49160-49200")
    if not svc["mpbx"].get("extra_hosts"): err.append("mpbx cannot reach coturn on the host (extra_hosts host-gateway)")
else:
    if svc["rtpengine"].get("network_mode") == "host": err.append("desktop file must not use host networking")
for e in err: print("   ", e)
sys.exit(1 if err else 0)
PY
done

echo "== coturn is not an open relay (W4-MED-02)"
# Every allocation authenticated (TURN REST shared secret), no TCP relay, no multicast, and the denied peer ranges
# (private, loopback, link-local incl. cloud metadata, CGNAT, special) identical in the dev sandbox, this bundle and
# the Kubernetes component.
python3 - coturn/turnserver.conf ../compose.yaml ../../k8s/components/turn/turnserver.conf <<'PY' && ok "auth required, deny list complete and identical in sandbox, prod and k8s" || bad "coturn configuration is weaker than required"
import re, sys
prod_path, sandbox_path, k8s_path = sys.argv[1:4]
def lines(p):
    return [l.strip() for l in open(p, encoding="utf-8") if l.strip() and not l.strip().startswith("#")]
prod = lines(prod_path)
err = []
for need in ("use-auth-secret", "no-tcp-relay", "no-multicast-peers", "no-cli", "fingerprint"):
    if need not in prod: err.append(f"{prod_path}: missing {need}")
for bad in ("no-auth", "allow-loopback-peers", "allowed-peer-ip", "lt-cred-mech", "static-auth-secret", "user="):
    if any(l.startswith(bad) for l in prod): err.append(f"{prod_path}: must not contain {bad}")
denied = [l.split("=", 1)[1] for l in prod if l.startswith("denied-peer-ip=")]
required = ["0.0.0.0-0.255.255.255", "10.0.0.0-10.255.255.255", "100.64.0.0-100.127.255.255", "127.0.0.0-127.255.255.255",
            "169.254.0.0-169.254.255.255", "172.16.0.0-172.31.255.255", "192.0.0.0-192.0.0.255",
            "192.168.0.0-192.168.255.255", "198.18.0.0-198.19.255.255", "224.0.0.0-255.255.255.255", "::1",
            "fc00::-fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "fe80::-febf:ffff:ffff:ffff:ffff:ffff:ffff:ffff"]
for r in required:
    if r not in denied: err.append(f"{prod_path}: denied-peer-ip={r} missing")
sandbox = re.findall(r'--denied-peer-ip=([^"\s]+)', open(sandbox_path, encoding="utf-8").read())
if sorted(sandbox) != sorted(denied): err.append(f"the sandbox ({sandbox_path}) and prod deny lists differ")
k8s = [l.split("=", 1)[1] for l in lines(k8s_path) if l.startswith("denied-peer-ip=")]
if sorted(k8s) != sorted(denied): err.append(f"the Kubernetes ({k8s_path}) and prod deny lists differ")
for e in err: print("   ", e)
sys.exit(1 if err else 0)
PY

echo "== optional Grafana bundle (W4-OBS-01): off by default, loopback only, read-only ClickHouse user, provisioned files"
json="$(render -f compose.yaml -f compose.linux.yaml)" || bad "does not render without profiles"
python3 - "$json" "$(render -f compose.yaml -f compose.linux.yaml --profile observability)" <<'PY' && ok "default install has no Prometheus or Grafana; the profile adds both, pinned and hardened" || bad "observability profile invariant violated"
import json, sys
off, on = json.loads(sys.argv[1])["services"], json.loads(sys.argv[2])["services"]
err = []
for name in ("prometheus", "alertmanager", "grafana"):
    if name in off: err.append(f"{name} runs without the observability profile")
    if name not in on: err.append(f"{name} missing with the observability profile")
g, p, am = on["grafana"], on["prometheus"], on["alertmanager"]
if "@sha256:" not in am.get("image", ""): err.append("Alertmanager image is not pinned by digest")
if [x.get("host_ip") for x in am.get("ports", [])] != ["127.0.0.1"]: err.append("Alertmanager must publish on 127.0.0.1 only")
if not am.get("read_only"): err.append("Alertmanager root file system is writable")
env = g["environment"]
if [x.get("host_ip") for x in g.get("ports", [])] != ["127.0.0.1"]: err.append("Grafana must publish on 127.0.0.1 only")
if p.get("ports"): err.append("Prometheus must not publish a port")
if not env.get("GF_PLUGINS_PREINSTALL", "").startswith("grafana-clickhouse-datasource@"): err.append("ClickHouse plugin is not installed at a pinned version")
if env.get("GF_AUTH_ANONYMOUS_ENABLED") != "false" or env.get("GF_USERS_ALLOW_SIGN_UP") != "false": err.append("anonymous access or sign-up is on")
if not p.get("read_only"): err.append("Prometheus root file system is writable")
for k in ("CLICKHOUSE_PASSWORD", "POSTGRES_PASSWORD", "MPBX_MASTER_KEY"):
    if k in env: err.append(f"Grafana gets {k}")
mounts = [v["source"].rstrip("/") for v in g.get("volumes", []) if v.get("target") == "/etc/grafana/provisioning"]
if not mounts or not mounts[0].endswith("grafana/provisioning"): err.append("Grafana provisioning is not mounted from ../grafana/provisioning")
for e in err: print("   ", e)
sys.exit(1 if err else 0)
PY
# FU-OBS01-L4: the air-gapped override turns the plugin download off and mounts the vendored plugin read-only.
off_json="$(placeholders+=(GRAFANA_PLUGINS_DIR=/srv/grafana-plugins); render -f compose.yaml -f compose.linux.yaml -f compose.grafana-offline.yaml --profile observability 2>/dev/null)" || off_json=""
python3 - "$off_json" <<'PY' && ok "compose.grafana-offline.yaml: no plugin download, vendored plugin mounted read-only" || bad "compose.grafana-offline.yaml invariant violated"
import json, sys
if not sys.argv[1]: sys.exit(1)
g = json.loads(sys.argv[1])["services"]["grafana"]
vol = [v for v in g.get("volumes", []) if v.get("target") == "/var/lib/grafana/plugins"]
sys.exit(0 if g["environment"].get("GF_PLUGINS_PREINSTALL", "x") == "" and vol and vol[0].get("read_only") else 1)
PY
# FU-W11OPS-3: compose.airgap.yaml names the loaded tag of every digest-pinned third-party image of compose.yaml.
python3 - <<'PY' && ok "compose.airgap.yaml: every digest-pinned image has its tag (docker load keeps tags, not index digests)" || bad "compose.airgap.yaml does not cover every digest-pinned image of compose.yaml"
import re, sys
main = open("compose.yaml", encoding="utf-8").read()
over = open("compose.airgap.yaml", encoding="utf-8").read()
pinned = dict(re.findall(r"^  ([a-z][a-z0-9_-]*):\s*\n(?:(?!^  [a-z]).*\n)*?\s+image: (\S+?)@sha256:[0-9a-f]{64}", main, re.M))
got = dict(re.findall(r"^  ([a-z][a-z0-9_-]*):\s*\n\s+image: (\S+)\s*$", over, re.M))
sys.exit(0 if pinned and pinned == got and not any("@" in v for v in got.values()) else 1)
PY
# FU-W9-AI-06-5c: the media stream overlay needs its public URL, then puts the listener on loopback and the URL on the API.
if ! render -f compose.yaml -f compose.linux.yaml -f compose.media-stream.yaml >/dev/null 2>&1; then
  ok "compose.media-stream.yaml refuses to render without MPBX_MEDIA_STREAM_URL"
else bad "compose.media-stream.yaml renders without MPBX_MEDIA_STREAM_URL"; fi
if (placeholders+=(MPBX_MEDIA_STREAM_URL=wss://pbx.example.com/v1/media-stream MPBX_MEDIA_STREAM_TICKET_KEY=PLACEHOLDER-SECRET); render -f compose.yaml -f compose.linux.yaml -f compose.media-stream.yaml 2>/dev/null) | python3 -c '
import json, sys
e = {n: s.get("environment", {}) for n, s in json.load(sys.stdin)["services"].items()}
ok = e["mpbx"].get("MPBX__MEDIA__STREAM_URL", "").startswith("wss://") and e["mpbx-media"].get("MPBX__MEDIA__STREAM_LISTEN", "").startswith("127.0.0.1:")
ok = ok and e["mpbx"].get("MPBX_MEDIA_STREAM_TICKET_KEY") and e["mpbx"].get("MPBX_MEDIA_STREAM_TICKET_KEY") == e["mpbx-media"].get("MPBX_MEDIA_STREAM_TICKET_KEY")
sys.exit(0 if ok else 1)'; then ok "compose.media-stream.yaml: wss:// URL on the API, loopback listener and the same ticket key on mpbx-media"
else bad "compose.media-stream.yaml: URL, listener or ticket key wrong"; fi
# FU-W9-AI-06-5d (4): without the Caddy front the API relays the route and the listener binds the bridge gateway.
if (placeholders+=(MPBX_MEDIA_STREAM_URL=wss://pbx.example.com/v1/media-stream MPBX_MEDIA_STREAM_TICKET_KEY=PLACEHOLDER-SECRET); render -f compose.yaml -f compose.linux.yaml -f compose.media-stream.yaml -f compose.media-stream-direct.yaml 2>/dev/null) | python3 -c '
import json, sys
e = {n: s.get("environment", {}) for n, s in json.load(sys.stdin)["services"].items()}
proxy = e["mpbx"].get("MPBX__MEDIA__STREAM_PROXY", "")
listen = e["mpbx-media"].get("MPBX__MEDIA__STREAM_LISTEN", "")
sys.exit(0 if proxy and proxy == listen and not listen.startswith("127.0.0.1:") and not listen.startswith("0.0.0.0:") else 1)'; then ok "compose.media-stream-direct.yaml: the API relays to the listener, which binds the bridge gateway (not loopback, not all interfaces)"
else bad "compose.media-stream-direct.yaml: relay target and listener address differ or are public"; fi
# FU-W11OPS-3-c: the extras of an air-gapped install (--turn, --observability with the offline Grafana plugin) render with
# the airgap overlay and then name NO digest-pinned image: every image resolves from a `docker load`ed tag.
for extra in "turn" "observability"; do
  prof=(--profile "$extra"); [ "$extra" = observability ] && prof=(--profile observability)
  files=(-f compose.yaml -f compose.linux.yaml -f compose.airgap.yaml); [ "$extra" = observability ] && files+=(-f compose.grafana-offline.yaml)
  if (placeholders+=(GRAFANA_PLUGINS_DIR=/srv/grafana-plugins); render "${files[@]}" "${prof[@]}" 2>/dev/null) | python3 -c '
import json, sys
d = json.load(sys.stdin)
bad = sorted(n + ": " + s["image"] for n, s in d["services"].items() if "@sha256:" in s.get("image", ""))
print("\n".join(bad)); sys.exit(1 if bad else 0)' >/tmp/mpbx-airgap-extra.out; then
    ok "air-gapped --$extra: renders and no service names a digest-pinned image"
  else
    bad "air-gapped --$extra: a service still names a digest-pinned image (or does not render)"; sed 's/^/    /' /tmp/mpbx-airgap-extra.out
  fi
done
rm -f /tmp/mpbx-airgap-extra.out
python3 ../grafana/tools/lint-dashboards.py >/tmp/mpbx-grafana-lint.out 2>&1 && ok "dashboards and datasources lint ($(tail -n2 /tmp/mpbx-grafana-lint.out | head -n1))" || { bad "dashboard lint failed"; sed 's/^/    /' /tmp/mpbx-grafana-lint.out; }
rm -f /tmp/mpbx-grafana-lint.out
python3 - <<'PY' && ok "Prometheus scrapes mpbx:9464 and loads the shipped rules" || bad "Prometheus config does not scrape mpbx:9464"
import sys
t = open("prometheus/prometheus.yml", encoding="utf-8").read()
l = open("prometheus/prometheus.linux.yml", encoding="utf-8").read()
ok_ = "mpbx:9464" in t and "/etc/prometheus/rules/*.yml" in t and "mpbx-media:9464" in t and "alertmanager:9093" in t
ok_ = ok_ and "mpbx-host:19465" in l and "mpbx-host:19464" in l and "alertmanager:9093" in l
sys.exit(0 if ok_ else 1)
PY

python3 - <<'PY' && ok "read-only ClickHouse profile: readonly=2, max+min 1 on time and rows, memory const (dev, prod, k8s copies)" || bad "mpbx_readonly profile can lift its limits (0 means unlimited)"
import sys, xml.etree.ElementTree as ET
err = []
for path in ("../clickhouse/users.d/readonly.xml", "clickhouse/users.d/readonly.xml", "../../k8s/base/files/clickhouse-readonly.xml"):
    prof = ET.parse(path).getroot().find("profiles/mpbx_readonly")
    if prof is None: err.append(f"{path}: no mpbx_readonly profile"); continue
    if prof.findtext("readonly") != "2": err.append(f"{path}: readonly is not 2")
    for k in ("max_execution_time", "max_result_rows", "max_memory_usage"):
        v = prof.findtext(k)
        if not v or int(v) < 1: err.append(f"{path}: {k} has no positive default")
    c = prof.find("constraints")
    for k in ("max_execution_time", "max_result_rows"):
        e = c.find(k) if c is not None else None
        if e is None or e.findtext("min") != "1" or not e.findtext("max"): err.append(f"{path}: {k} needs <min>1</min> and <max>")
    m = c.find("max_memory_usage") if c is not None else None
    if m is None or m.find("const") is None: err.append(f"{path}: max_memory_usage must be <const/> (0 is allowed past <min>)")
for e in err: print("   ", e)
sys.exit(1 if err else 0)
PY
echo "== rtpengine keeps a silent session long enough (W2-EMR-01: a caller queued at an emergency centre)"
# shellcheck disable=SC2016 # the ${...} are the script's literal text, matched, not expanded
t="$(sed -n 's/.*--timeout="${RTPE_TIMEOUT:-\([0-9]*\)}".*/\1/p' rtpengine/start.sh)"
# shellcheck disable=SC2016
s="$(sed -n 's/.*--silent-timeout="${RTPE_SILENT_TIMEOUT:-\([0-9]*\)}".*/\1/p' rtpengine/start.sh)"
if [ -n "$t" ] && [ "$t" -ge 300 ] && [ -n "$s" ] && [ "$s" -ge 3600 ]; then
  ok "rtpengine/start.sh: --timeout=$t --silent-timeout=$s"
else
  bad "rtpengine/start.sh must pass --timeout >= 300 and --silent-timeout >= 3600 (got '${t}' / '${s}')"
fi

echo "== per-company Grafana ClickHouse users (FU-OBS01-L3)"
python3 -I scripts/grafana-company-user-test.py >/tmp/mpbx-company-user.out 2>&1 && ok "company-user generator: every tenant table is filtered, fail closed" || { bad "grafana-company-user-test failed"; sed 's/^/    /' /tmp/mpbx-company-user.out; }
grep -q 'company-users.xml' compose.yaml && ok "compose mounts company-users.xml" || bad "compose.yaml must mount clickhouse/company-users.xml"

echo
if [ "$fail" = 0 ]; then echo "validate: PASS"; else echo "validate: FAIL"; fi
exit "$fail"
